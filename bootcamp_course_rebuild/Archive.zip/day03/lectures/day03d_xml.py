# we will use this file to learn about xml
import xml.etree.ElementTree as ET

# below we pass in the file we want to parse as a string
# notice we didn't pass in a file object like we did with json.load()
tree = ET.parse("country_data.xml")

root = tree.getroot()
print(root)

for child in root:
    print(child.tag, child.attrib)

    # notice that the attributes are stored as dictionaries
    # this is because an element can have multiple attributes
    # prints:
    # country {'name': 'Liechtenstein'}
    # country {'name': 'Singapore'}
    # country {'name': 'Panama'}

    #### uncomment the below to see nested children of child
    # for grandchild in child:
    #     print(grandchild.text) # will print text if there is any
    #     print(grandchild.attrib) # prints dictionaries containing the attributes.

# we can acces specific children by indexing
my_child = root[1]
print(my_child.attrib)

my_grandchild = root[2][0]
print(my_grandchild)

# Practice: Create a countries dict, where each country is mapped to another dictionary which contains info about rank, year, gdp
country_dict = {}
for child in root:
    country = child.attrib['name']
    print(list(child))
    attrib_dict = {}
    for gc in child:
        tag = gc.tag.lower()
        if tag in ['rank', 'year', 'gdppc']:
            attrib_dict[tag] = gc.text
    country_dict[country] = attrib_dict

print(country_dict)