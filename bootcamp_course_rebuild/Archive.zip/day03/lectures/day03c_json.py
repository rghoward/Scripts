import json

##### Notes #####
astr = '{"cat":3, "dog":2}' # a JSON formatted string
print(type(astr))
# we will use json.loads() "loads = load string" to format this into a python dict 
adict = json.loads(astr)
print(adict)
print(type(adict))

# below we will load a file using json.load()
adict = json.load(open("book.json"))
print(adict) #{'cat': 3, 'dog': 4, 'bird': None}
# in javascript (json too) they use null but python uses None so json.load() will convert null to None as seen above

# the below the same thing
with open("book.json") as f:
    adict = json.load(f)
    print(adict)

# let's convert a dict to a json object stored as a strin
bdict ={"cat":None, "dog":7}
newstr = json.dumps(bdict) # converts bdict to a json formatted string
print(newstr)
print(type(newstr))

# lets' convert a python dict to a json object stored as a file
# the first parameter in dump() is a dictionary the second is a writeable file object
bdict ={"cat":None, "dog":7}
json.dump(bdict, open("newbook.json", "w"))

# this does same thing
with open ("newbook.json", "w") as f:
    json.dump(bdict, f)

clist = json.load(open("schedule.json"))
print(clist)

from pprint import pprint
pprint(clist)


##### Practice Problem #####

#Write a function that takes in the name of a file and if the file is json formatted, 
#returns a list of the keys available in the json file. 
#If the file is not a json formatted file, return None. Call your function get_keys.

# Hint: use try...except
def return_JSON_keys(filename):
    try:
        adict = json.load(open(filename))
        return(list(adict.keys()))
    except:
        return None
    
print(return_JSON_keys("book.json"))
print(return_JSON_keys("airtravel.csv"))