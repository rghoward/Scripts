import re


############ Beautiful Soup ##############
 
#### Using Beautiful Soup on Local Files ####

# 1. How do we find the largest text on the page?
from bs4 import BeautifulSoup

# first open the file storing our html data
with open("lecture20.html") as f:
    soup = BeautifulSoup(f, "html.parser")

# print(soup) # soup contains the entire text from the html file
h1_tag = soup.find('h1') # this finds the first h1 tag
print(h1_tag) # prints <h1>Cats</h1>
print(h1_tag.text) # prints "Cats"

# 2. find the info in the unordered list
ul_tag = soup.find("ul")
# print(ul_tag)
catlist = ul_tag.find_all("li")
print(catlist)
print([li.text for li in catlist]) # each li is an li tag so we can acces the text of that li tag

# 3. find the info in the 2nd unordered list
ul_tags = soup.find_all("ul")
print(ul_tags)
real_catlist = ul_tags[1].find_all("li")
print(real_catlist)
print([c.text for c in real_catlist])

##### Using Beautiful Soup with internet pages #####
# use this website: https://www.scrapethissite.com/pages/simple/

# 1. List all country names
import requests
from bs4 import BeautifulSoup
resp = requests.get("https://www.scrapethissite.com/pages/simple/")
soup = BeautifulSoup(resp.text, "html.parser")
country_tags = soup.find_all("h3")
# print(country_tags)
names = [c.text.strip() for c in country_tags]
print(names)

# 2. print each country along with its capital
# we got the soup content above so we don't need to make another request
tags = soup.find_all("div", {"class": "col-md-4 country"}) # we first found all div tags that matched the class attribute col-md-4 country
for tag in tags:
    country_tag = tag.find("h3")
    capital_tag = tag.find("span", {"class":"country-capital"})
    print(country_tag.text.strip(), capital_tag.text.strip())

# 3. build a dictionary with the keys as country names and the values as population of that country
country_pop_dict = {}
for tag in tags: # we found tags in #2 above
    country_tag = tag.find("h3")
    pop_tag = tag.find("span", {"class":"country-population"})
    country_pop_dict[country_tag.text.strip()] = pop_tag.text.strip()
print(country_pop_dict["Zambia"])

# 4. create a dictionary mapping each country name to a dictionary containing info about that country
country_dict = {}
for tag in tags:
    country_tag = tag.find('h3') # get country name
    population_tag = tag.find("span", {"class":"country-population"}) # get country population
    area_tag = tag.find("span", {"class":"country-area"}) # get country area
    capital_tag = tag.find("span", {"class":"country-capital"}) # get country capital

    country = country_tag.text.strip()
    area = area_tag.text.strip()
    capital = capital_tag.text.strip()
    population = population_tag.text.strip()

    # create a dict mapping each country to a dict containing info about it.
    country_dict[country] = {'capital':capital, 'area':area, 'population':population}

print(country_dict['Angola']['population'])
