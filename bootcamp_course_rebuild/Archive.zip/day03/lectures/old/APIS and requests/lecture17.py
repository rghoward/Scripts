# import requests # imports the requests module to use it
# url = "https://anapioficeandfire.com/api"
# r = requests.get(url)
# print(r)  # prints the status code only
# print(r.status_code)
# print(r.text[:1000]) # prints the text
# data = r.json()  # converts json text to python
# print(type(data))  # a dictionary
# print(data.keys())  # The dictionary’s keys

# # List the titles of all the Game of Thrones books in alphabetical order.
# url = "https://www.anapioficeandfire.com/api/books"
# r = requests.get(url)
# # we know from the documentation that this data is stored in json format
# data = r.json()

# book_list = [] # make an empty list to store book names
# for book in data: # book is a dictionary containing information about a book from GoT
#     book_list.append(book['name'])
# book_list.sort()
# print(book_list)

# # 1. How many houses exist in the universe of fire and ice?
# url = "https://www.anapioficeandfire.com/api/houses"
# r = requests.get(url)
# data = r.json()
# print(f"There are {len(data)} houses in GoT")

# # 2. Which of the houses have the most sworn members?
# # this question builds off of the one above.  We'll be using same data.
# house_name = ""
# sworn_members = 0
# for house in data:
#     num_members = len(house['swornMembers'])
#     if num_members > sworn_members:
#         house_name = house['name']
#         sworn_members = num_members
# print(f"{house_name} is the largest house with {sworn_members} members.")

# # 3. What is the title of the book that is the most pages long?
# url = "https://www.anapioficeandfire.com/api/books"
# r = requests.get(url)
# data = r.json()

# most_pages = 0
# biggest_book = ""
# for book in data:
#     pages = book['numberOfPages']
#     if pages > most_pages:
#         most_pages = pages
#         biggest_book = book['name']
# print(f"{biggest_book} is the longest at {most_pages} pages.")

################
# everything above sent json responses
# let's look at a non-json response
import requests
url = "http://cc.gatech.edu"
r = requests.get(url)
print(r)  # prints the status code only
print(r.text[:10000]) # prints the text

### the below gives an error because the response is in html not json
#data = r.json()  # converts json text to python
###