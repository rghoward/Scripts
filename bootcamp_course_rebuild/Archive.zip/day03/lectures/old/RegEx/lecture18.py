import re

### re.match() looks for a match at the beginning of a string
pattern = "te"
text = "Does the beginning of the text match?"
match = re.match(pattern, text)
print(match)  # a Match object or None
if match: # since we didn't match using the match() method which looks at the beginning of the string, match = None
	s = match.start()
	e = match.end()
	print(text[s:e])


### we cause use re.search() if we want to find a match anywhere in the string
pattern = "te"
text = "Does the beginning of the text match?"
match = re.search(pattern, text)
print(match)  # <re.Match object; span=(26, 28), match='te'>
if match: # since we didn't match using the match() method which looks at the beginning of the string, match = None
    s = match.start()
    e = match.end()
    print(text[s:e])
    print(match.group())

### we can use re.findall() to find a list of substrings that match our pattern without overlap
pattern = "he"
text = "The text might have multiple matches."
substring_list = re.findall(pattern, text)
print(substring_list)
for match in substring_list:
    print(f'Found {match}')


### if we want a list of match objects instead of a list of substrings, we can use re.finditer()
pattern = "he"
text = "The text might have multiple matches."
matches = re.finditer(pattern, text)
print(matches)
for match in matches:
    print('Found {}'.format(match))

### play with character classes
pattern = "[a-z]"
text = "This is a string."
matches = re.findall(pattern, text)
print(matches) # ['h', 'i', 's', 'i', 's', 'a', 's', 't', 'r', 'i', 'n', 'g']

## what would happen if we searched for [^a-z]
pattern = "[^a-z]"
text = "This is a string."
matches = re.findall(pattern, text)
print(matches) #['T', ' ', ' ', ' ', '.']

# find all the sequences of two or three x's
# including one number before and after
text = "12x34xx56xxx78xxxx910"
pattern = "[^x]x{2,3}[^x]"
# let's break down the above pattern
# we start with [^x] which says find one character that is not an x
# then we have x{2,3} which says we should find a minimum of 2 to a max of 3 x's immediately followint the character from before
# the last [^x] says we should have one closing character that is not an x.
matches = re.findall(pattern,text)
print(matches)


#### practice questions
text = "Now is the time to go to cc.gatech.edu and use find_gt or find_students to do the questions on pages 2, 25, 101, and 153. I hope you enjoy."

# Write one statement to retrieve a list of all the sequences of lowercase letters joined with a underscore within the text above.
pattern = "[a-z]+_[a-z]{1,}" # note + and {1,} does the same thing
matches = re.findall(pattern,text)
print(matches)

# Write one statement to retrieve a list of all the individual digits in the text.
pattern = "\d"
matches = re.findall(pattern,text)
print(matches)

# Write one statement to retrieve a list of all the capitalized words in the text.
pattern = "[A-Z][a-z]*" # * star should be used because some words are just a single capital letter
matches = re.findall(pattern,text)
print(matches)

# Write one statement to retrieve a list of all the sequences of characters ending with a period or comma.
pattern = "[^,. ]*[.,]" # my answer was "[a-zA-Z0-9]+[.,]"
matches = re.findall(pattern,text)
print(matches)