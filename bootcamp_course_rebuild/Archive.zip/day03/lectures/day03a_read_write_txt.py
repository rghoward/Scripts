import csv # allows us to use csv module

# this function 1 way that we can read files
def read_example1():
    f = open("example.txt") # f is a file object
    # print(f)
    text = f.read() # this reads in all data as a single string
    print(text)
    f.close() # don't forget to close your file if you use this method to open files
    # we close files to release the memory that they are using
# read_example1()

def read_example2():
    #this is an alternative but the PREFERRED way to open files
    # with open()... will close the file automatically for us
    with open("example.txt") as f:
        # text = f.read()
        # print(text)

        # f.readline() reads up to and including the end of line marker (\n)
        # good if you only the first line
        first_line = f.readline()
        print(first_line)

        # every use of readline() will move the cursor of the file object to the beginning
        # of the next line
        next_line = f.readline()
        print(next_line)

        # we can also use f.readlines()
        # readlines will store all "remaining" lines of the text as a list of strings
        lines = f.readlines() # lines is a list of lines where each line is a string
        print(type(lines))
        print(lines)
    for i, line in enumerate(lines):
        print(i, line)
# read_example2()

def write_example():
   # we can write to files using "w" or "a" as a permission
    # below we make a new file and write to it
    with open("text_file1.txt", "w") as outfile:
        outfile.write("one\ntwo\nthree")
# write_example()

def write_example2():
    # if we write to files using the "a" permission
    # if the file doesn't exist, it will make a new file and write to it
    # if the file does exist, it adds new data to end of file
    with open("text_file2.txt", "a") as outfile:
        outfile.write("a\nb\nc")
write_example2()

# write a function that takes in two filenames as parameters,
# reads the text from the first file and write it to the 2nd with all punctuation removed
def remove_punctuation(input_file, output_file):
    with open(input_file) as f:
        input_text = f.read() # read in text from first file
    with open(output_file, "w") as f:
        output_text = ""
        for symbol in input_text:
            # keeps alphabet, number, whitespace
            if symbol.isalpha() or symbol.isdigit() or symbol.isspace():
                output_text += symbol
        f.write(output_text)
remove_punctuation("course_schedule.txt", "course_schedule_clean.txt")
