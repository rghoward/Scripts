import csv

# write a function that uses the data from airtravel.csv to calculate the average number 
# of transatlantic passengers per month for the year 1960 in thousands of passengers
def avg_per_month(input_filename):
    with open(input_filename) as f:
        # we need to throw away the header
        f.readline()
        lines = f.readlines() # get the remaining lines
    sum = 0
    count = 0
    for line in lines:
        entries = line.split(",")
        # try allows us to try something and if it fails it doesn't crash our program
        try:
            sum += int(entries[-1].strip())
            count += 1
        except:
            pass
    avg = sum / count
    print(f"The average is: {avg}")
# avg_per_month("airtravel.csv")

def csv_reader_example():
    with open("airtravel.csv") as file1:
        reader = csv.reader(file1, delimiter=",", quotechar='"')
        print(reader) # reader object
        reader_list = list(reader) # we cast the reader object to a list
        print(reader_list)
# csv_reader_example()

def csv_writer_example():
    data = [["row1data1","row1data2"], ["row2data1", "row2data2"]]
    headers = ["headerdata1", "headerdata2"]
    
    with open("output.csv", "w") as f:
        writer = csv.writer(f, lineterminator="\n")
        writer.writerow(headers)
        writer.writerows(data)
# csv_writer_example()

# dict reader example
def csv_dict_reader():
    # csv.DictReader() maps the info in each row to a dict
    # the keys in each dict will come from the first row in the csv file (header)
    # unless we specify what the fieldnames are
    with open("airtravel.csv") as csvfile:
        reader = csv.DictReader(csvfile)
        print(reader.fieldnames)
        for row in reader:
            print(row)
# csv_dict_reader()

def csv_dict_reader2():
    with open("airtravel.csv") as csvfile:
        reader= csv.DictReader(csvfile, fieldnames=["Month", 1958, 1959, 1960])
        print(reader.fieldnames)
        for row in reader:
            print(row[1958])
# csv_dict_reader2()


def csv_dict_writer():
    with open("names.csv", "w") as csvfile:
        headers = ['first_name', 'last_name']
        writer = csv.DictWriter(csvfile, fieldnames=headers) # fieldnames are the keys to our dicts
        writer.writeheader()
        writer.writerow({'first_name': 'Baked', 'last_name': "Beans"})
        writer.writerow({'first_name': "Lovely", 'last_name': "Spam"})
        writer.writerow({'first_name': "Wonderful", 'last_name': "Spam"})
# csv_dict_writer()

# 1. Use the file countries.csv to calculate the average population of a country whose 
# name starts with an A.  

def avg_pop():
    with open("countries.csv") as f:
        reader = csv.DictReader(f)
        pop = 0
        count = 0
        for row in reader:
            if row['Country'][0].lower() == "a":
                pop += int(row['Population'])
                count += 1
        avg = pop/count
        print(f"The average of A countries is: {avg}")
# avg_pop()

# 2. Create a new file called big_countries.csv that contains only the lines from 
# the countries.csv file that have a population over 50 million.  You should also include the header line in this new file.
def big_countries():
    with open("countries.csv") as f:
        reader = csv.DictReader(f)
        header = reader.fieldnames
        print(header)
        new_countries = []
        for row in reader:
            if int(row["Population"]) > 50000000:
                new_countries.append(row)
    with open("big_countries.csv", "w") as f:
        writer = csv.DictWriter(f, fieldnames=header)
        writer.writeheader()
        writer.writerows(new_countries)
# big_countries()

# 3. Create a new file called country_basics.csv that contains only the first four 
# columns and the column that gives you the GDP for that country from the countries.csv
# file. (5 columns total).  You should also
# include the portions of the header line that are required. 
def country_basics():
    with open("countries.csv") as f:
        reader = csv.reader(f,delimiter=",", quotechar='"')
        lines = list(reader)
        header = lines[0][:4] + [lines[0][8]]

        data = []
        for item in lines[1:]:
            row = item[:4] + [item[8]]
            data.append(row)
    
    with open("country_basics.csv", "w") as f:
        writer = csv.writer(f, lineterminator='\n')
        writer.writerow(header)
        writer.writerows(data)


country_basics()