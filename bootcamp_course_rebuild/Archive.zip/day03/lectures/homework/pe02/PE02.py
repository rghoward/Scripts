import json, datetime, csv
from pprint import pprint


def read_txt(input_file):
    """
    Question 1
    - menu.txt contains google trend data about the popularity of fine dining menus
    - Read the menu.txt with FILE I/O or CSV.
    - Return a list of lists without whitespace. (Remove '\n's basically)
    - Exclude the columns "Olive Garden Menu" and "Red Lobster Menu"

    Args:
        input_file (menu.txt)
    Returns:
        List of Lists

    Output:

    [['Month', "Chili's Menu", "Applebee's Menu", 'Outback Steakhouse Menu'],
     ['2004-01', '2', '2', '2'],
     ['2004-02', '2', '2', '1'],
     ['2004-03', '1', '2', '1'],
     ['2004-04', '1', '1', '1'],
     ...
     ['2021-04', '19', '56', '14'],
     ['2021-05', '19', '59', '15']]
    """
    pass


def write_to_json(cleaned_list, output_file):
    """
    Question 2
    - Using the cleaned list of lists from question 1, create a dictionary that maps the month
    to an inner dictionary.
    - The inner dictionary keys should be "Chili's Menu", "Applebee's Menu", "Outback Steakhouse Menu"
      with their values being the values they correspond to.
    - Write the dictionary to a JSON file with the name passed in as output_file.
    - Return the dictionary.

    Args:
        cleaned_list (list)
        output_flie (str)
    Returns:
        dict

    Output:
     {'2004-01': {"Applebee's Menu": '2',
                  "Chili's Menu": '2',
                  'Outback Steakhouse Menu': '2'},
      '2004-02': {"Applebee's Menu": '2',
                  "Chili's Menu": '2',
                  'Outback Steakhouse Menu': '1'},
      '2004-03': {"Applebee's Menu": '2',
                  "Chili's Menu": '1',
                  'Outback Steakhouse Menu': '1'},,
      ...
      '2021-05': {"Applebee's Menu": '59',
                  "Chili's Menu": '19',
                  'Outback Steakhouse Menu': '15'}}


    """
    pass


def popular_months(cleaned_list, output_file):
    """
    Question 3
    - Using the cleaned list of lists from question 1, sort the months by Outback's
    menu popularity in descending order.

    - Create a file that displays the worst and best months using the format:
    "Outback was struggling during {month}, where its popularity was {Outback's Menu Popularity}.
     However, it was at its peak during {month} where its popularity was {Outback's Menu Popularity}!"

    - Make sure to add a new line between both sentences.
    - Keep in mind when you are sorting that the "popularity" values are str and not int.
    - Return the sorted list

    Args:
        cleaned_list (list)
        output_file (str)
    Returns:
        list of lists

    Output:
        [['2017-04', '36', '40', '30'],
         ['2017-05', '40', '36', '27'],
         ['2012-02', '36', '41', '26'],
          ...
         ['2006-07', '3', '6', '1'],
         ['2004-06', '2', '1', '0']]

    Output file:
        Outback was struggling during 2004-06 where its popularity was 0.
        However, it was at its peak during 2017-04 where its popularity was 30!


    """
    pass

#####################################
#Question 4 and 5 use new_values.csv#
#####################################

def average_popularity(new_values, specified_popularity):
    """
    Question 4
    - Read new_values.csv with CSV and create the a dictionary of the average popularity of each restaurant
    - Only add the restaurant to the dictionary if its average popularity is greater than or equal to
        the specified_popularity and if their name is composed of more than a two words.
    - Have the keys be the restaurant name and the values be the avg_popularity rounded to two decimals
    - Return the dictionary

    Args:
        input_file (menu.txt)
        specified_popularity (int)
    Return:
        dict

    >> (average_popularity("new_values.csv", 20))
    Output: {'Olive Garden Menu': 28.12, 'Outback Steakhouse menu': 43.15, 'Red Lobster Menu': 22.88}

    >> (average_popularity("new_values.csv", 40)
    Ouput: {'Outback Steakhouse menu': 43.15}

    >> (average_popularity("new_values.csv", 50)
    Output: {}

    """
    pass

def update_futures(input_file, new_values, output_file):
    """
    Question 5
    - Combine information in new_values.csv with the values in menu.txt
    - Add the combined data to output_file.csv
    - Make sure not to erase the old values
    - Make sure not to add the header line twice
    - Return a list of lists of the output_file

    Args:
        input_file (menu.txt)
        new_values (new_values.csv)
        output_file (futures.csv)
    Return:
        list of lists

    Output:
    >> update_futures("menu.txt", "new_values.csv", "futures.csv")

          [['Month',
            "Chili's Menu",
            'Olive Garden Menu',
            "Applebee's Menu",
            'Outback Steakhouse Menu',
            'Red Lobster Menu'],
           ['2004-01', '2', '2', '2', '2', '1'],
           ['2004-02', '2', '3', '2', '1', '3'],
           ...
           ['2026-11', '22', '8', '25', '37', '29'],
           ['2026-12', '38', '5', '34', '44', '7']]

    >> len(update_futures("menu.txt", "new_values.csv", "futures.csv"))
         277

    """

    pass

def correction(input_file):
    '''
    Question 6
    - The data seems to have been corrupted! The popularity of Red Lobster has been underestimated.
    - Given the information in menu.txt, increase the popularity values of Red Lobster by 25%.
    - Make sure to round the new values to the nearest whole number.
    - No need to write/modify any files. Just return the updated list
    Args:
        input_file (menu.txt)
    Return:
        new list of lists
    Output:
    >> correction("menu.txt")
    [['Month',
      "Chili's Menu",
      'Olive Garden Menu',
      "Applebee's Menu",
      'Outback Steakhouse Menu',
      'Red Lobster Menu'],
     ['2004-01', '2', '2', '2', '2', 1.0],
     ['2004-02', '2', '3', '2', '1', 4.0],

     ...
     ['2021-04', '19', '67', '56', '14', 30.0],
     ['2021-05', '19', '71', '59', '15', 35.0]]


    '''

    pass


def new_restaurant(input_file):

    '''
    Question 7
    - Given the information in menu.txt, add a new column for Tratoria Pizza Place.
    - To find the popularity of the new restaurant on any given month, simply multiply the value for Chilis' popularity times the
      month number.
    - No need to write/modify any files. Just return the updated list
    Args:
        input_file (menu.txt)
    Return:
        new list of lists
    Output:
    >> new_restaurant("menu.txt")
    [['Month',
      "Chili's Menu",
      'Olive Garden Menu',
      "Applebee's Menu",
      'Outback Steakhouse Menu',
      'Red Lobster Menu',
      'Tratoria Pizza Place'],
     ['2004-01', '2', '2', '2', '2', '1', 2],
     ['2004-02', '2', '3', '2', '1', '3', 4],
     ...
     ['2021-04', '19', '67', '56', '14', '24', 76],
     ['2021-05', '19', '71', '59', '15', '28', 95]]

    '''

    pass


def adjustment(updated_list):

    '''
    Question 8
    - Using the updated list from the previous question.
    - We realize that there is a maximum to the popularity of a restaurant. So, in the added column for Tratoria,
      we would like to make sure the values are capped to 70. If the popularity is above 70, modify it so that it is
      exactly 70.
    - No need to write/modify any files. Just return the updated list

    Args:
        updated_list (result from Question 7)
    Return:
        new list of lists
    Output:
    >> updated_list = new_restaurant("menu.txt")
    >> adjustment(updated_list)
    [['Month',
      "Chili's Menu",
      'Olive Garden Menu',
      "Applebee's Menu",
      'Outback Steakhouse Menu',
      'Red Lobster Menu',
      'Tratoria Pizza Place'],
     ['2004-01', '2', '2', '2', '2', '1', 2],
     ['2004-02', '2', '3', '2', '1', '3', 4],
     ...
     ['2021-04', '19', '67', '56', '14', '24', 70],
     ['2021-05', '19', '71', '59', '15', '28', 70]]


    '''

    pass


if __name__ == '__main__':

    # Test your functions within this block

    pass




