
import requests
from bs4 import BeautifulSoup
import re

def get_status_code(url):
    response = requests.get(url)
    return response.status_code

def get_json_data(url):
    response = requests.get(url)
    return response.json()

def get_lion_data(json_data):
    return json_data.get("lion")

def post_data(url, payload):
    response = requests.post(url, json=payload)
    return response.status_code

def get_html_title(file_path):
    with open(file_path, 'r') as file:
        soup = BeautifulSoup(file, 'html.parser')
    return soup.title.string

def get_paragraph_texts(file_path):
    with open(file_path, 'r') as file:
        soup = BeautifulSoup(file, 'html.parser')
    paragraphs = [p.text for p in soup.find_all('p')]
    return paragraphs

def get_hyperlinks(file_path):
    with open(file_path, 'r') as file:
        soup = BeautifulSoup(file, 'html.parser')
    links = [a['href'] for a in soup.find_all('a', href=True)]
    return links

def find_lowercase_underscore(text):
    pattern = r'[a-z]+_[a-z]+'
    return re.findall(pattern, text)

def find_digits(text):
    pattern = r'\d'
    return re.findall(pattern, text)

def find_capitalized_words(text):
    pattern = r'[A-Z][a-z]*'
    return re.findall(pattern, text)
