

"""
Homework 03: Web Scraping and Data Processing with The Lion King Theme

Instructions:
1. Solve each problem by writing a function definition.
2. The function should perform the task described in the problem.
3. Make sure to test your functions to ensure they work correctly.
4. Submit your completed hw03.py file.

Good luck, and Hakuna Matata!

Note: Each problem should be solved using a function definition. The function name and parameters are provided. You should only fill in the function body.
"""

# Problem 1: Making an HTTP GET request
# Write a function that makes an HTTP GET request to the URL "https://example.com" and returns the status code.
def get_status_code(url):
    pass

# Problem 2: Parsing JSON from an API response
# Write a function that makes an HTTP GET request to the URL "https://api.example.com/data" and returns the parsed JSON data.
def get_json_data(url):
    pass

# Problem 3: Extracting data from JSON
# Write a function that extracts the value associated with the key "lion" from the JSON data returned by get_json_data function.
def get_lion_data(json_data):
    pass

# Problem 4: Making an HTTP POST request
# Write a function that makes an HTTP POST request to the URL "https://api.example.com/data" with JSON payload {"name": "Simba"} and returns the status code.
def post_data(url, payload):
    pass

# Problem 5: Parsing HTML with BeautifulSoup
# Write a function that reads the content of "lion_king.html", parses it with BeautifulSoup, and returns the title of the page.
def get_html_title(file_path):
    pass

# Problem 6: Extracting text from HTML
# Write a function that reads the content of "lion_king.html", parses it with BeautifulSoup, and returns all paragraph texts as a list.
def get_paragraph_texts(file_path):
    pass

# Problem 7: Extracting links from HTML
# Write a function that reads the content of "lion_king.html", parses it with BeautifulSoup, and returns all hyperlinks (URLs) as a list.
def get_hyperlinks(file_path):
    pass

# Problem 8: Regular Expressions - Finding patterns
# Write a function that takes a string and returns all sequences of lowercase letters joined with an underscore.
def find_lowercase_underscore(text):
    pass

# Problem 9: Regular Expressions - Extracting digits
# Write a function that takes a string and returns all individual digits as a list.
def find_digits(text):
    pass

# Problem 10: Regular Expressions - Capitalized words
# Write a function that takes a string and returns all capitalized words as a list.
def find_capitalized_words(text):
    pass
