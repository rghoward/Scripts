# hw05_solution.py
# Solution for Homework 5 - Mario Themed Data Analysis and Visualization

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 1. Create a DataFrame representing different Mario characters with attributes like power, coins collected, and level.
def create_mario_dataframe():
    data = {
        'character': ['Mario', 'Luigi', 'Peach', 'Toad', 'Yoshi'],
        'power': [8, 7, 6, 5, 7],
        'coins_collected': [100, 85, 90, 50, 60],
        'level': [10, 9, 9, 7, 8]
    }
    df = pd.DataFrame(data)
    return df

# 2. Add a column to the DataFrame calculating the total score for each character (e.g., power * coins collected).
def add_score_column(df):
    df['score'] = df['power'] * df['coins_collected']
    return df

# 3. Filter the DataFrame to include only characters with a score above a certain threshold.
def filter_high_scores(df, threshold):
    return df[df['score'] > threshold]

# 4. Create a scatter plot showing the relationship between power and coins collected by each character.
def plot_power_vs_coins(df):
    df.plot(kind='scatter', x='power', y='coins_collected', color='blue')
    plt.title("Power vs Coins Collected")
    plt.xlabel("Power")
    plt.ylabel("Coins Collected")
    plt.show()

# 5. Fit a trend line to the scatter plot created in the previous step.
def fit_trend_line(df):
    x = df['power']
    y = df['coins_collected']
    z = np.polyfit(x, y, 1)
    p = np.poly1d(z)
    plt.scatter(x, y)
    plt.plot(x, p(x), color='red')
    plt.title("Power vs Coins Collected with Trend Line")
    plt.xlabel("Power")
    plt.ylabel("Coins Collected")
    plt.show()
    return p

# 6. Create a line plot to visualize the progression of a single character's scores across multiple levels.
def plot_character_progression(df, character_name):
    char_df = df[df['character'] == character_name]
    plt.plot(char_df['level'], char_df['score'], marker='o')
    plt.title(f"Progression of {character_name}'s Score Across Levels")
    plt.xlabel("Level")
    plt.ylabel("Score")
    plt.show()

# 7. Calculate the average score per level across all characters and add this as a new column to the DataFrame.
def add_average_score_per_level(df):
    df['average_score_per_level'] = df['score'] / df['level']
    return df

# 8. Plot the average score per level as a line plot.
def plot_average_score(df):
    df.plot(kind='line', x='level', y='average_score_per_level', color='green')
    plt.title("Average Score Per Level")
    plt.xlabel("Level")
    plt.ylabel("Average Score Per Level")
    plt.show()

# 9. Determine which character has the maximum score and return the character's name.
def find_max_score_character(df):
    max_score_char = df.loc[df['score'].idxmax()]['character']
    return max_score_char

# 10. Save the modified DataFrame with all additional columns to a new CSV file.
def save_dataframe_to_csv(df, filename):
    df.to_csv(filename, index=False)
