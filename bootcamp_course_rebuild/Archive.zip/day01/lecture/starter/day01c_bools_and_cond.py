# === Boolean expressions and intro to conditionals
print("boolean expressions:")
print("----------------------------------")
# Relational operators
"""
< less than
> greater than
<= less than or equal to
>= greater than or equal to
== equals
!= not equals
"""
print(5 > 6) # False
print(7<90) # True
print(8<=8) #True
print(120 == 240/2)
print(1 != -1)

# Relational operations result in booleans
a_bool = 35 < 45 # This would store True into a_bool
another_bool = 34 == 14 # False is stored into another_bool


# === Building conditional blocks
print("\nBuilding conditional blocks:")
print("----------------------------------")
"""
ONE if
and OPTIONALLY as many elif as you want
and OPTIONALLY ONE else - else is what to do if all other conditions are not met.
"""

# if

if True: # this always evaluates to True
    print("always true")

if False: # this always evaluates to False
    print('this will never be printed')

grade = 89
if grade >= 90:
    print("A")

grade = 70
if grade == 70:
    print("Your grade is 70")

# if and else
grade = 80
if grade >= 90:
    print("You got an A")
else:
    print("You are not smart!")

# if, elif and else
grade = 54
if grade >= 90:
    print("A")
elif grade>= 80:
    print("B")
elif grade >= 70:
    print("C")
elif grade >= 60:
    print("D")
else:
    print("You got an F")

# another way:
# if grade < 60:
#     print("F")
# elif grade < 70:
#     # and so on.


# what's wrong with the following?

grade = 95
if grade >= 60:
    print("D")
elif grade >= 70:
    print("C")
elif grade >= 80:
    print("B")
elif grade >= 90:
    print("A")

# if/if vs. if/elif

grade = 95
if grade >= 60:
    print("D") # once the first condition is met, Python does not look at other elifs
elif grade >= 70:
    print("C")

# since an if statement is always the beginning of a conditional block
# multiple if's will be evaluated. 
grade = 95
if grade >= 60:
    print("D")
if grade >= 70:
    print("C")

# === Conditionals in functions
print("\nConditionals in functions:")
print("----------------------------------")
# Example: Write a function that takes as input someone's
# midterm grades and returns their letter grade for the course.


def letterGrade(m1, m2):
    avgGrade = (m1+m2)/2
    if avgGrade >= 90:
        return "A"
    elif avgGrade >= 80:
        return "B"
    elif avgGrade >= 70:
        return "C"
    elif avgGrade >= 60:
        return "D"
    else:
        return "F"

print(letterGrade(75, 85))


# === Logical operators (not, and, or)
print("\nlogical operators: ")
print("----------------------------")

# and

print(True and True) #> True 
print(True and False) #> False
print(False and False) #> False

grade = 97
attendance = 8
if grade >= 90 and attendance >= 95: # True and False -> False
    print("You are an awesome student!")
else:
    print("You are a terrible student.")


# or

print(True or True) # True
print(True or False) # True
print(False or False) # False

grade = 97
attendance = 8
if grade >= 90 or attendance >= 95: # True or False -> True
    print("You are an awesome student!")
else:
    print("You are a terrible student.")

# not # takes a boolean and changes it to the opposite

print(not True) # False
print(not False) # True

grade = 92
if not grade < 90: # not False -> True
    print("you get an A") # gets printed


# using them all at once
print("\nLogical operator order of operations:")
print("-------------------------------------------")
"""
Logical Operators have an order of operations
parentheses take precedence
not is evaluated first # for example not False and True -> True and True
and is evaluated second left to right
or is evaluated last
"""
grade = 90
attendance = 11

if grade >= 90 and attendance >= 90 or grade == 100: 
    print("A")

# True and False or False
# False or False
# False

grade = 100
attendance = 5
if grade >= 90 and attendance >= 90 or grade == 100: 
    print("A")

# True and False or True
# False or True
# True

grade = 100
attendance = 5
if grade >= 90 and attendance >= 90: # True and False > False
    print("A")
elif grade >= 90 and not attendance < 10: # True and not True > True and False > False
    print("B")

grade = 11
if grade < 10 or grade < 20 and not grade > 30:
    print("cool.")

# False or True and not False
# False or True and True
# False or True
# True

# === Functions that return booleans
print("\n functions with boolean returns")
print("-----------------------------------")
# Example: Write a function that checks whether a number is odd

def isOdd(num):
    remainder = num%2
    return remainder == 1

print(isOdd(6))
print(isOdd(5))

# Example: Write a function that checks whether a password
# is correct or not

def isValidPWD(pwd):
    if pwd == 'hi123':
        return True
    else:
        return False

print(isValidPWD("HI345"))


# === The in operator
print("\n in operator: ")
print("-------------------------------")
# the in operator returns true if a substring appears in a string (matched exactly)
# will work for finding items in lists, tuples, and dicts later on.

print('el' in "hello") # True
print('no' in "hello")  # False

# Example: Write a function that checks whether a breed of
# animal is a dog or not
def is_dog(breed):
    if breed in "husky, golden retriever, pitbull, corgi, dachschund":
        return True
    else:
        return False

print(is_dog("golden retriever")) # True
print(is_dog("chihuaha")) # False




# Example: Write a function that creates targetted ads based
# on someone's chat

def targeted_ad(message):
    if "burger" in message or "Burger" in message:
        print("Come to 5 guys!")
    elif "chicken" in message:
        print("Come to chic-fil-a")
    elif "lipstick" in message:
        print("Come to Ulta!")
targeted_ad("I'm so hungry, I want a burger!")        

# === Nested if statements
print("\nNested if statements:")
print("----------------------------")
# Example: Is it a good day to go hiking? > Try at home!

#  Temperature | Weather | Play?
#     T > 80   |  rainy  |  yes
#     T > 80   |  clear  |  no
#    50 <= T   |  clear  |  yes
#    50 <= T   |  rainy  |  no

temp = 90
weather = 'rainy'

def play(temp, weather):
    if temp > 80:
        if weather == "rainy":
            return True
        else:
            return False
    elif temp <= 50:
        if weather == "clear":
            return True
        else:
            return False
        
print(play(90,'rainy'))