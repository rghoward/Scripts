"""
Day 1 - pt. A - Intro and basics

What we're doing this time
0. IDLE
1. Identifiers
    a. What are variables?
    b. Rules and Naming Conventions
    c. Miniquiz!
2. Data types
    a. What are a few data types?
    b. str, int, float, bool
    c. How do I know what type a value is?
    d. Converting/Casting to Different Types
3. Expressions
    a. What are expressions?
    b. Operators (+ - * / ** % //)
    c. Order of Operations
    d. Miniquiz!
4. Grabbing Values from User Input
    a. What is input()?
    b. Caveats
"""

print("Variable Names:")
print("----------------------------------")
# Variable names follow some important rules

# 1. variable names can only contain letters, numbers, and
# underscores _

boot_camp24 = "This is our bootcamp!"


# 2. variables names MUST start with a letter or an
# underscore
# 1301cs = 5 # will not work since it starts with a number

# 24bootcamp = "bootcamp" <- didn't work because it started with a number
_bootcamp = "hi" # while allowed, typically you won't start with an underscore.
bootcamp = "hi"


# 3. variables cannot be Python keywords
"""
del
and
or
not
True (however, true is not a python keyword and can be used)
False (false is not a python keyword and can be used)
--plus many others: https://www.programiz.com/python-programming/keyword-list
"""

# Variable naming conventions have been developed to make
# code more consistent among different users.

# 1. should start with a lowercase letter
chocolate = "Kinder"

# 2. if the variable name contains multiple words
# you should separate them
# with an underscore for example: snake_case
# yummyChocolate

yummy_chocolate = "Beast"

# === Data types
print("\nData Types:")
print("----------------------------------")
# str (string)
# strings can be stored using double quotes "" or single quotes ''
# strings store sequences of characters
# don't use str as a variable name 
a_str = "this is a string!"
b_str = "132428923489234789" # <- be careful here, this is not considered a number 
print(a_str)
print(b_str)
print(type(b_str)) # the type function will tell you the type of data stored

# int (integer)
# can only store integers--not other types of numbers
an_int = 98 # this is an int
print(an_int)
print(type(an_int))


# float (float)
# can store decimals

a_float = -1.7
print(a_float)

# you can perform math operations with floats and ints together
print(an_int + a_float) # 96.3


# bool (boolean)
# booleans have one of two values: True or False
t_bool = True
f_bool = False

print(type(t_bool))
print(f_bool)

a_str = "1"
b_str = 2
#print(a_str+b_str) # TypeError: can only concatenate str (not "int") to str

# === Converting/casting
print("\ncasting: ")
print("----------------------------------")
# we can "cast" (convert) one data type to another when we need to ensure they are the
# same data type.
var1 = "1"
var2 = 2
# print(var1+var2) # doesn't work because they are different data types

# we can "cast" (convert) one data type to another to ensure they are the same data type
x = int(var1)
print(type(var1)) # str
print(type(x)) # int

print(x + var2) # 1 + 2 -> 3

# we can cast directly
print(int("27") + 32.1) # 27 + 32.1

"""
COMMON TYPE CASTING FUNCTIONS:
int(): Converts a value to an integer.
float(): Converts a value to a floating-point number.
str(): Converts a value to a string.
bool(): Converts a value to a boolean. # converts the number 1 to True and 0 to False

# ALSO COMMON BUT WE WILL LEARN LATER:
list(): Converts a value to a list.
tuple(): Converts a value to a tuple.
set(): Converts a value to a set.
dict(): Converts a sequence of key-value pairs to a dictionary.
"""

# === Expressions
print("\nExpressions:")
print("----------------------------------")
# an expression is a combination of values, variables, operators, 
# and function calls that are evaluated to produce a new value.

# + sum or concatenation
var1 = 10 + 30 # 10+30 is an expression

# + works with strings to concatenate
str1 = "hello"
str2 = "everyone!"
str3 = str1 + " " + str2
print(str3)

# - subtraction
a = 1
b = 2
print(a-b)


# * multiplication

a = 9
b =7
print(a*b)

my_str = "hi"
print(my_str * 3) # "hihihi" # repeated concatenation with itself.

# / division (will ALWAYS give back a float, even if you use two ints)
print(9/3)
print(7/16)

# // floor division (used for integers)
# // will give back an int if used with 2 ints.  However, will give back a float if there is a float in the expression.
print(5.0//2)
print(5//2)

# % modulo operation (remainder of integer division)
print(5%2) # 1 because the remainder of 5/2 is 1
print(99%23)


# ** exponentiation
print(2**5) # 32
print(4**(1/2)) # 2.0

# === Order of operations is going to be P E MD AS
print("\nOrder of Operations:")
print("----------------------------------")
# (same tier operations are performed left to right)
# parentheses are the only grouping symbol don't use brackets they are for other things

# Example: Calculating the average temperature for today
min_temp = 85
max_temp = 120

avg_temp = (min_temp + max_temp) / 2


# Example: Calculating the volume of water in a cylinder
height = 8
radius = 3.5
pi = 3.14

area =  pi * radius ** 2
volume = area * height
print(volume)


# === Collecting user input using the input() function
print("\ninput():")
print("----------------------------------")



# Example: Writing a script that asks how many popsicles
# a user wants and tells them the total cost.

price = 4.0
tax = 0.1
tip = 0.25

n_pops = input("How many popsicles would you like? ")
print(type(n_pops)) # this is a string we should cast it to an int

total = price * int(n_pops) * (1 + tip + tax)
print("Your order total is $" + str(total))