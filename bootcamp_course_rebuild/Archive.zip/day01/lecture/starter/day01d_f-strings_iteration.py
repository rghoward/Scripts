# === 0. f-strings

print("f-strings: ")
print("----------------------------------")
# f-strings provide a concise and readable way to include 
# expressions inside string literals, using curly braces {}.
# format f"stringstuf {x} more string stuff" where x is some variable

# create a variable for your name and another for your age
# print out: "Hello, my name is {name} and I am {age} years old."
name = 'ronnie'
age = 36

greeting_str = "Hi my name is " + name + " and I am " + str(age)
print(greeting_str)

greeting_str2 = f"Hi my name is {name} and I am {age}"
print(greeting_str2)

# or we could have just printed directly:
print(f"Hi my name is {name} and I am {age}")

# === Iteration
print("\niteration:")
print("----------------------------------")
'''
iteration - a way to do something over and over again in code
repeatedly run a snippet of code
'''

# === While loop: while some condition is True, keep running
# this piece of code
print("\nWhile Loops: ")
print("----------------------------------")

"""
3 key ingredients:
    - Initialization
    - Terminating condition
    - Moving towards terminating condition (typically)
"""


# Example: Printing hello n times

n = 5 # initialization

while n > 0: # n>0 <- terminating condition
    print("hello")
    n -= 1 # move towards terminating condition



def placeAnOrder():
    # initialization:
    order = input("What would you like? ")
    while order != "Nothing else":
        print(f"{order} is coming right up!")
        order = input("What else?") # <- approach terminating condition
# placeAnOrder()

        
# === For loop:
print("\nFor Loops:")
print("----------------------------------")
# for each item in compoundDataType1
# for each part of a whole
# for each thing in a collection of things

# Example: Looping through a string and printing each
# character in a separate line

aStr = "Hello"

for c in aStr: # "H", "e", "l", "l", "o"
    # 1 -> c = "H"
    # 2 -> c = "e"
    #... 
    print(c)

print("\nrange:")
# Example: Looping through a range of values
"""
three forms of range:
-- note that range's stop value is exclusive
-- range is a built-in python function that returns an iterable starting at some value and ending at some value. 
"""

# you can think of range as internally being a sequence of numbers.
#range(1, 11, 2) #-> 1,3,5,7,9 
#range(5, 7) #-> 5,6
#range(3) # 0,1,2

# often we use range() with for loops to do an iteration a certain number of times.

for i in range(11):# -> start from 0, go all the way up to stop (non-inclusive)
    # i = 0, i = 1, i = 2, ..., i = 10
    print(i)


for j in range(1, 12): #-> start from start, go all the way up to stop (non-inclusive on stop)
     # j = 1, j = 2, j = 3, ... j = 11
    print(2*j)

for k in range(2, 8, 5):#-> start from start, go to stop by step size
    # k = 2, k = 7
    print(k)

# you can also go backwards if you use a negative step-size:
for m in range(100, 0, -5):
    # m = 100, m= 95, ... m= 5
    print(m)

print('\nFor Loops examples: ')
print("----------------------------------")
# === Counting with loops
# Example: counting the vowels in a string
def countVowels(aStr):
    count = 0 # we currently have counted no vowels, initialize count outside of loop
    for char in aStr:
        # count = 0 <- bad don't do this. 
        if char in "AEIOUaeiou": # char = "h", char = "e" , ...
            count += 1
        # return count <- this is bad because the return is in the loop which means only 1 loop occurs before returning
    return count 

    # I need to visit every character -> loop!
    # count only the ones that are vowels -> conditional!
    # keep track of count

sentence = "hello"
print(f'There are {countVowels(sentence)} vowels in the word "{sentence}"')

sentence = "It is not raining outside"
print(f'There are {countVowels(sentence)} vowels in the word "{sentence}"')

# Example: building a string that contains only the lower case
# characters from another string
def keep_lower(sent):
    lower_sent = "" # "" <- an empty string
    for c in sent:
        if c in "abcdefghijklmnopqrstuvwxyz":
            lower_sent += c
    return lower_sent

sentence = "ThIS is Fun!"
print(keep_lower(sentence))

# === Continue statement
print("\nContinue Examples: ")
print("----------------------------------")

# Example: cleaning data from a faulty sensor
def cleanData(aStr):
    # build a str without the hyphens
    # visit every char
    # check if it is a -
    newStr = ""
    for char in aStr: # char = "1", char = "2", char = "-", char = "3"
        print(char)
        if char == "-":
            continue
        newStr += char
    return newStr

data = "12-32-2---234"
print(cleanData(data))

# === Break statement
print("\nBreak examples:")
print("----------------------------------")

# Example: write a function that returns the first position
# of a target letter on a string

def findPosition(aStr, char):
    # visit every character
    # check whether I found the char
    # keep track of its position
    position = 0
    for c in aStr: # c = "3"
        if c == char:
            break
        position += 1
    return position

anotherStr = "3,1,5,a,8"
print(findPosition(anotherStr,"1"))


# Example: Write a function that decrypts the following message
# by keeping the characters located on indices divisible by 3
def decrypt(message):
    new = ""
    for i in range(0, len(message), 3): # start at 0 (divisible 3) and count by 3's
        new += message[i]
    return new



message = " ascdwooiolkl"
print(decrypt(message))

print("\nNested Loops: ")
print("----------------------------------")

# === Nested loops
# Example: Printing the pairs of numbers between 0 and n whose
# sum is divisible by 2.

def print_even_pairs(N):
    for i in range(N): # start at 0, then 1, then 2, ...
        for j in range(N): # this loop will run to completion before returning to the outer loop
            # print(i,j)
            if (i+j) % 2 == 0: # (i=0,j=0), (i=0, j=1), (i=0, j= 2)....
                print(i,j)

print_even_pairs(3)
