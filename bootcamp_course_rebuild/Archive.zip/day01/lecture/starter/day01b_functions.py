"""
3. Functions
    a. Declaring
    b. Calling
    d. Parameters
    e. Returning vs printing
    f. Combining functions
"""

# === Functions: Why functions?

# Example: Calculating the volume of various bricks
w1 = 5
h1 = 10
l1 = 6
vol1 = w1*h1*l1

w2 = 2
h2 = 7
l2 = 8
vol2 = w2*h2*l2

w3 = 1
h3 = 2
l3 = 1
vol1 = w3*h3*l3

# seems like we are repeating code...
# maybe there is a better way...

# === Functions: Declaring and calling a function
print("Intro to Functions:")
print("----------------------------------")
# Example: Write a function that greets a customer


# defining or declaring
def greet():
    print("Welcome to class!")

# print(2) # this is not part of the function because we tabbed back over
greet() # calling the function!
greet()
greet()
greet()


# Example: Write a function that asks a customer
# how many bubble teas they would like and tells
# them the total cost of their order.
def order():
    n_teas = "7"
    price = 5.0
    print("Your total is $" + str(int(n_teas)*price))

order()

# === Functions: Parameters and arguments
print("\nFunctions: parameters and arguments:")
print("----------------------------------")
# Follow-up: Calculating the volume of various bricks

def volBrick(w, h, l): # parameters
    print(w*h*l)

volBrick(1,2,3) # arguments
volBrick(3,4,5)


# Example: Write a function that takes as input
# the total number of cake layers and calculates
# the total cost of the cake

def cakeCost(nLayers):
    print("Your cake costs $"+str(nLayers*3.0))

cakeCost(5)

# === Functions: Scope
print("\nScope:")
print("----------------------------------")
# Example: Writing a function that takes as input
# the radius, height and density of a cake and prints
# the total weight of the cake.

def cakeWeight(radius, height, density):
    volume = radius ** 2 * 3.14 * height
    weight = volume * density
    print(weight)

cakeWeight(2,3,1.2)

# volume and weight defined in the function above are within the scope of the function only
# we cannot use them outside of the function
# print(volume)
# print(weight)

# both of these error because the volume variable defined above only exist
# within the scope of the function
# print(volume) 
# print(weight)


# === Functions: Return
print("\nreturn statement")
print("----------------------------------")
#The return statement in Python is used in functions to exit the function
# and return a value to the caller.


# Example: Write a function that takes as input the
# amount of caffeine per volume in a drink and returns
# the total amount of caffeine contained in that drink.

def caffeine(percent,vol):
    print("this runs")
    return percent * vol
    print("this will never run")

caff1 = caffeine(.05,2) # -> caff1 = 0.1
caff2 = caffeine(.1,8)
caffeine(3,7) # the function runs here but the value is not stored anywhere
print(caff1)
print(caff2)
print(caffeine(3,7))



# === Shortcut operators
print("\nShortcut Operators:")
print("----------------------------------")
# it is often the case that you will need to update the value of a variable

count = 0
count = count + 1 # count = 0 + 1
count = count + 5 # count = 1 + 5

# since the above is so common, there are some shortcuts for these:
# +=
count2 = 10
count2 += 20
print(count2)

# also works with concatenating strings:
a_str = "Good "
a_str += "Morning!"
print(a_str)

# -=
count_down = 50
count_down -= 4
print(count_down)

# *=
a_num = 45
a_num *= 0.5
print(a_num)

a_str = "hi"
a_str *= 5
print(a_str)

# /=
a_num = 50
a_num /= 2
print(a_num)

# === Functions: Combining functions
print("\nCombining Functions:")
print("----------------------------------")
# Example: Write a set of functions that calculates
# how much clay you will need to create a sculpture
# in a pottery class.
# the sculpture will contain a sphere of some radius, 
# a cube of some width
# and two cylinders that have the same radius but can differ from the sphere.

def sph_vol(radius):
    return 4/3 *(radius**3) * 3.14

def cyl_vol(radius, height):
    return 3.14 * radius**2 * height

def cub_vol(width):
    return width ** 3

def sculpture_vol(r_sph, r_cyl, h_cyl, w_cube):
    vol_sph = sph_vol(r_sph)
    v_cyl = cyl_vol(r_cyl, h_cyl)
    v_cube = cub_vol(w_cube)
    return 2*v_cyl + vol_sph + v_cube

total_vol = sculpture_vol(3,4,2,7)
print(total_vol)
# === Functions: Builtin python functions
# type()
# print()
# many more: https://www.w3schools.com/python/python_ref_functions.asp


# all functions have a return value even if not specified
def my_f1():
    return 2
a = my_f1()

def my_f2():
    print(2) # print is not the return value
    # if there isn't a return value specified
    # None is returned


b = my_f2()
print(b)
print(type(b)) # NoneType

def my_f3():
    a = 6
    if a%2 == 1:
        return "odd"
    elif a-2 < 0:
        return "negative"
    # return None if none of the conditions above are met
    