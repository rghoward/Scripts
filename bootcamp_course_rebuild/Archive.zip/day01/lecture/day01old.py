# python identifiers are the names we give to variables
# we can bound to an object using the assignment operator =

a = 5
b = 3

# you'll notice above that I didn't specify the data type
# compared to many languages, python is dynamically typed 
# meaning we do not need to specify the data type

# in python 3 (compared to 2) print is a function
print(b)
c = a + b
print(c)

# we can use different identifiers to refer to the same object
a = "Test"
b = a 
print(b)

# multiple identifiers can share the same object to save space
# use the id() function to return the address for the data
id(a)
id(b)
print("\n")

# reassigning b doesn't affect a
b = 10
print(b)
print(a)

# we can remove an identifier using del() function
# note that the data is not deleted
# however, if the data has no references, it will be garbage collected
del(a)
#print(a) this leads to a NameError 

# if we're unsure of the datatype of an identifier, we can use type()
print(type("f"))
print(type(b))

# type coercion
a = float(3)
print(a) # we see that a is a float
print(type(str(3.9)))
print(bool(1))
print(bool(0))
print(bool("0")) #non empty strings will be cast to True
print(bool("")) #empty strings will be cast to False
print("\n")

#### Division ####
# In python 3 all division with / produces floating point results
print(3/2) # converts to float
print(4/2) # also float

# if you want integer division use //
print(3//2) # does floor division
print(4//2)
print(4.0//2) # if one of the numbers are a float, it reverts to float division
print("\n")

#### Numerical Operators ####
# + is add
# - is subtract
# * multiplication
# / division
# // force integer division
# ** raise to power
# % modulo
print(2**6) # 64
print(49%14) # 7

#### Blocks ####
# python uses whitespace to indicate blocks
# note that user input is a string
### you can uncomment below to see some blocks in action

# num = input("enter a number")
# # colons are used to represent an indented block
# if int(num) > 10: 
#     print("Bigger than 10!")
#     x = True
# else:
#     print("Not bigger than 10!")
#     x = False


##### go back to page 21

#### functions ####
# to create a function use def function_name(param1, param2,...)
def areaOfCircle(radius):
    return 3.14*radius**2

# we can call a function
area = areaOfCircle(10)
print(area)

# areaOfCircle is the identifier for the function above
# if we write areaOfCircle, we'd get a memory address
print(areaOfCircle)

# you can also identify existing functions with other names
q = areaOfCircle
print(q(10)) # q is mapped to areaOfCircle function and so we can call it


#### Namespaces ####
# variables defined outside of functions have global scope
myVar = 7

# variables within a function (local scope) overshadow global scope
def myFunction():
    myVar = 8
    print(myVar)  # we see this prints 8

# but myVar below is mapped to 7 still even after we call myFunction
myFunction() # prints 8
print(myVar) # myVar is unchanged

# if you want to update a global variable within a function, then
myVar = 20
def myFunction2():
    # first use the global keyword to tell python that we want the global variable.
    global myVar
    # now we can update it
    myVar = 50
myFunction2()
print(myVar)

#### conditionals ####
# conditionals execute a block of code if a boolean expression is True
if 5 > 2:
    print("5 is bigger than 2")
#### the conditional ends when indentation reverts

# we can chain conditionals using if, elif, else
x = 5
if x < 4:
    print("small")
elif x==4:
    print("equal")
else:
    print("large")
print("anything after the chain always executes")

#### looping with while ####
i = 0
while i < 5:
    print("In the loop:", i)
    i = i + 1
print("After the loop:", i) # you can print two things using a comma


#### Sequence data types ####
# all sequence data types can be indexed into using []
# remember that indexing starts at 0

### Strings

# strings can be made using "" or ''
str1 = "I do crossfit at home"
str2 = 'I have 3 cats'
print(str1[0])
print(type(str2[0]))

# strings are immutable
# immutable means you cannot update the object after creation
#str1[0] = "i" # TypeError: 'str' object does not support item assignment

# tuples are immutable collections of data
# the data types do not have to be the same
tuple1 = (5,2,"apple")
print(tuple1[2])
# immutable means that you cannot update the object after 
# tuple1[2] = 3 # TypeError: 'tuple' object does not support item assignment

# lists are mutable collections of data
# the data types do not have to be the same
list1 = [1, True, 44.9]
print(list1[1])
list1[1] = False
print(list1)

# .append() adds an item to end of list
list1.append(7)
print(list1)

# .extend() extends a list using another sequence
list1.extend((7,3))
print(list1)

# .pop() returns and then removes last item from list
last_item = list1.pop()
print(last_item)
print(list1)

# .sort(reverse=False) sorts items (must be same data type)
list2 = [3,2,1,7]
list2.sort()
print(list2)

# .remove() removes an item at particular index
list2.remove(2)
print(list2)

# .insert(index, item) inserts an item at particular index
list2.insert(2,"five")
print(list2)


### Hint: you can grab the items from a list or tuple at same time
# this is called "unpacking"
tuple2 = (5,4)
a,b = tuple2
print(a)
print(b)

# the above can be great when retrieving multiple return values
def myFunction3():
    return 1,2,3 # multiple return values are returned as a tuple

x = myFunction3()
print(x)

# or we can unpack 
a,b,c = myFunction3()
print(a)
print(b)
print(c)

#### range() function ####
# range creates a sequence of numbers
#range(start, stop, end)
a = range(5) # creates a sequence going from 0 to 4
print(a) 

b = range(4,9) # first value is inclusive
print(b)

c = range(4, 11, 3)
print(c)

# range objects can be cast to lists
print(list(b))

### range is mostly useful for the for loop discussed below

#### for loop ####
# the for loop iterates through some kind of sequence such as the range object
for i in range(0,7):
    print(i)


# for loops can iterate through any kind of iterable
for letter in "This is my string":
    print(letter)

aTuple = (1,"pineapple", True)
for item in aTuple:
    print (item)

#### Sequences and Indexing ####
alist= ['a', 5, False, 33.2]
# indexing
print(alist[2])

# len() function
print(len(alist))

# since len() returns an int, we can use it to index to last element
#print(alist[len(alist)]) # IndexError: list index out of range
print(alist[len(alist)-1])
# we can also get last item using -1
print(alist[-1])

#### Sequences and Slicing ####
# slice operator makes a copy of a section of a sequence
# slicing is done as follow [start:stop:step]
# start is inclusive, stop is exclusive
alist= ['a', 5, False, 33.2]
print(alist[1:3])
print(alist[:4:2]) # if start is missing, 0 is default
print(alist[::2]) # if stop is missing, then end of list is default

## we know we can't update strings since they are immutable
name = "ronnie"
# name[0] = "R" # gives error

# however, we can create new strings and concatenate!
name = "R" + name[1:]
print(name)

#### go back to page 46

#### More about Lists ####
# lists are sequences of references
# see slide 46
aList = ['a', 5, 'Test']
# when you update an "item" in a list, you're really just updating the reference
aList[1] = 8
print(aList)

# del operator removes a reference from a list
del aList[1]
print(aList)

#### Aliases ####
# aliases are identifiers pointing to same list
batman = ['a', 5, 'Test']
bruce = batman

# if we update an alias, the change is reflected in both identifiers
bruce[2] = 'bam!'
print(bruce)
print(batman)

#### Slicing makes shallow copies ####
batman = ['a', 5, 'Test']
bruce = batman[:]
# if we change a shallow copy, then the original is unaffected
bruce[1] = 7
print(bruce)
print(batman)

# however, a shallow copy, only goes 1 layer deep
# if our list contains a list
# and we update the list within a shallow copy, then the list changes in both
aList = ['a', 'b', ['x','y']]
bList = aList[:]
bList[0] = 1
bList[2][0] = 'a'
print(bList)
print(aList)


#### Dictionaries ####
# a dictionary is a set of keys that reference values
# think of it as a key:value mapping
# {} are used for dictionaries 
dictA = {'ronnie':"howard", 'bob':"smith"}
print(dictA['ronnie'])
print(dictA)

# you can add new k:v pairs
dictA["John"] = "Smith"

# you can update dictionary references
dictA['ronnie'] = "Howard"
print(dictA)


print(dictA.keys()) # gets the keys
print(dictA.values()) # gets the values
print(dictA.items()) # gets the items

#### in and not in operators ####
batman = ['a', 5, 'Test']
print("test" in batman)
print("Test" in batman)

if "ca" in "cat":
    print("CATS!")
if "dog" not in "cats":
    print("CATS")

# we can use in to test keys in dictionary
dictA = {'ronnie':"howard", 'bob':"smith"}
print( "ronnie" in dictA)

#### importing modules ####
# imports SHOULD BE DONE at top of python file
# but python allows them anywhere
import math
sin = math.sin
print(sin(0.5))

# you can also just import a particular function form a module
from math import sinh
print(sinh(.5))

# the * wildcard allws you to import all functions/attributes from module
from math import *
print(sin(0.5))
print(cos(0.5))
print(pi)

#### be careful not to overwrite functions you import
# sin = "potato"
# print(sin(0.5)) # TypeError: 'str' object is not callable

# you can rename imported names using 'as' keyword
from math import sin as mathsin
print(mathsin(0.5))