# === Boolean expressions and intro to conditionals

# Example: Write a snippet of code that tells athletes what
# building they should go to based on their sport.

mySport = "volleyball"
if mySport == "swimming":
    print("Building 2A")

# Relational operators
"""
< less than
> greater than
<= less than or equal to
>= greater than or equal to
== equals
!= not equals
"""

print(5 > 6)
print(7 < 90)
print(8 <= 8)
print(120 == 110)
print(130 != 900)

# Relational operations result in booleans

aBool = 35 < 45
print(aBool)

anotherBool = 34 == 14 # False
print(anotherBool)

# === Building conditional blocks
"""
ONE if
and OPTIONALLY as many elif as you want
and OPTIONALLY ONE else - else is what to do if all other conditions are not met.
"""

# if

if True: # this always evaluates to True
    print("always true")

if False: # this always evaluates to False
    print('this will never be printed')

grade = 89
if grade >= 90: # if True
    print("A") # not printed since 89 >= 90 is False

# if and else

grade = 80
if grade >= 90:
    print("A")
else:
    print("Not an A, :(")

    # if, elif and else

grade = 54
if grade >= 90:
    print("A")
elif grade >= 80:
    print("B")
elif grade >= 70:
    print("C")
elif grade >= 60:
    print("D")
else:
    print("F")

# another way:
grade = 100
if grade < 60:
    print("F")
elif grade <70:
    print("D")
elif grade < 80:
    print("C")
elif grade < 90:
    print("B")
else:
    print("A")


# what's wrong with the following?

grade = 95
if grade >= 60:
    print("D")
elif grade >= 70:
    print("C")
elif grade >= 80:
    print("B")
elif grade >= 90:
    print("A")

    # if/if vs. if/elif

grade = 95
if grade >= 60:
    print("D") # once the first condition is met, Python does not look at other elifs
elif grade >= 70:
    print("C")

# since an if statement is always the beginning of a conditional block
# multiple if's will be evaluated. 
grade = 95
if grade >= 60:
    print("D")
if grade >= 70:
    print("C")

    # === Conditionals in functions

# Example: Write a function that takes as input someone's
# midterm grades and returns their letter grade for the course.


def letterGrade(m1, m2):
    avgGrade = (m1+m2)/2
    if avgGrade >= 90:
        return "A"
    elif avgGrade >= 80:
        return "B"
    elif avgGrade >= 70:
        return "C"
    elif avgGrade >= 60:
        return "D"
    else:
        return "F"

print(letterGrade(75, 85))


# === Logical operators (not, and, or)


# and

print(True and True) #> True 
print(True and False) #> False
print(False and False) #> False

grade = 97
attendance = 8
if grade >= 90 and attendance >= 95: # True and True
    print("You got an A! Yay!")
else:
    print("You failed because a condition was not met. :(")


# or

print(True or True)
print(True or False)
print(False or False)

if grade >= 90 or attendance >= 95:
    print("You are a good student!")
else:
    print(":(")

# not

aBool = True
print(not aBool)
anotherBool = False
print(not anotherBool)

grade = 92

if not grade < 90:
    print("you get an A.")


# using them all at once
    
"""
Logical Operators have an order ofoperations
not is evaluated first
and is evaluated second left to right
or is evaluated last
"""
grade = 90
attendance = 91

if grade >= 90 and attendance >= 90 or grade == 100: 
    print("A")

# True and True or False
# True or False
# True

grade = 100
attendance = 5
if grade >= 90 and attendance >= 90 or grade == 100: 
    print("A")

# True and False or True
# False or True
# True

grade = 100
attendance = 5
if grade >= 90 and attendance >= 90: # True and False > False
    print("A")
elif grade >= 90 and not attendance < 10: # True and not True > True and False > False
    print("B")

grade = 11
if grade < 10 or grade < 20 and not grade > 30:
    print("cool.")


# === Functions that return booleans

# Example: Write a function that checks whether a number is odd

def isOdd(num):
    remainder = num%2
    return remainder == 1

print(isOdd(6))
print(isOdd(5))

# Example: Write a function that checks whether a password
# is correct or not

def isValidPWD(pwd):
    if pwd == 'hi123':
        return True
    else:
        return False

print(isValidPWD("HI345"))


# === The in operator

# the in operator returns true if a substring appears in a string (matched exactly)
# will work for finding items in lists, tuples, and dicts later on.

# Example: Write a function that checks whether a breed of
# animal is a dog or not



def betterIsDog(breed):
    if breed in "husky, golden retriever, pitbull, corgi, dachshund":
        return True
    else:
        return False

print(betterIsDog("golden retriever")) # True (there is a match!)
print(betterIsDog("goldenretriever")) # False (not a match!)


# Example: Write a function that creates targetted ads based
# on someone's chat



def targettedAd(message):
    if "burger" in message or "Burger" in message:
        print("Come to 5 guys!")
    elif "chicken" in message:
        print("Come to Chic-fil-a!")
    elif "lipstick" in message:
        print("Come to Ulta!")
targettedAd("I'm so hungry, I feel a Burger for lunch!")

# === Nested if statements

# Example: Is it a good day to go hiking? > Try at home!

#  Temperature | Weather | Play?
#     T > 80   |  rainy  |  yes
#     T > 80   |  clear  |  no
#    50 <= T   |  clear  |  yes
#    50 <= T   |  rainy  |  no

temp = 90
weather = 'rainy'

def play(temp, weather):
    if temp > 80:
        if weather == 'rainy':
            return True
        else:
            return False
    elif temp >= 50:
        if weather == 'clear':
            return True
        else:
            return False
print(play(90, 'rainy'))