"""
Day 1 - pt. A - Intro and basics

What we're doing this time
0. IDLE
1. Identifiers
    a. What are variables?
    b. Rules and Naming Conventions
    c. Miniquiz!
2. Data types
    a. What are a few data types?
    b. str, int, float, bool
    c. How do I know what type a value is?
    d. Converting/Casting to Different Types
3. Expressions
    a. What are expressions?
    b. Operators (+ - * / ** % //)
    c. Order of Operations
    d. Miniquiz!
4. Grabbing Values from User Input
    a. What is input()?
    b. Caveats
"""


# === Script vs. shell
# script is a file containing commands to be executed within the shell
# the code in this file is a script
# shell is a program providing a command-line interface for interacting with the OS (operating system)

# === Comments
# comments are used to explain code, make it readable and provide context
# comments are ignored by the Python interpreter.
# This is a one line comment.

"""
This is a multi-line string.
However, many developers use this as a multi-line comment in python.
print(3+3) <- nothing prints since it is inside this "comment"
"""

'''
You can also use 3 single quotes instead
'''

"""
Day 1 - pt. A - Intro and basics

What we're doing this time
0. IDLE
1. Identifiers
    a. What are variables?
    b. Rules and Naming Conventions
    c. Miniquiz!
2. Data types
    a. What are a few data types?
    b. str, int, float, bool
    c. How do I know what type a value is?
    d. Converting/Casting to Different Types
3. Expressions
    a. What are expressions?
    b. Operators (+ - * / ** % //)
    c. Order of Operations
    d. Miniquiz!
4. Grabbing Values from User Input
    a. What is input()?
    b. Caveats
"""


# === Script vs. shell
# script is a file containing commands to be executed within the shell
# the code in this file is a script
# shell is a program providing a command-line interface for interacting with the OS (operating system)

# === Comments
# comments are used to explain code, make it readable and provide context
# comments are ignored by the Python interpreter.
# This is a one line comment.

"""
This is a multi-line string.
However, many developers use this as a multi-line comment in python.
print(3+3) <- nothing prints since it is inside this "comment"
"""

'''
You can also use 3 single quotes instead
'''

# Variable names follow some important rules

# 1. variable names can only contain letters, numbers, and
# underscores _
cs1301 = "This is my favorite class!"
#cs1301! = "This is my favorite class!" # this errors because ! is not allowed in a variable name


# 2. variables names MUST start with a letter or an
# underscore
# 1301cs = 5 # will not work since it starts with a number
_1301cs = 5 # should work
print(_1301cs) # starting a varaible with an underscore will always work but is usually reserved for certain circumstances.
# typically you should start with a lowercase letter.



# 3. variables cannot be Python keywords
"""
del
and
or
not
True (however, true is not a python keyword and can be used)
False (false is not a python keyword and can be used)
"""

# Variable naming conventions have been developed to make
# code more consistent among different users.

# 1. should start with a lowercase letter
chocolate = "Kinder"

# 2. if the variable name contains multiple words
# you should separate them
# with an underscore for example: snake_case

yummy_chocolate = "Beast"

# === Data types

# str (string)
# strings can be stored using double quotes "" or single quotes ''
# strings store sequences of characters
# don't use str as a variable name 
aStr = "This is a string!"
bStr = "11111323423423423" # this is not a number, it is a string
print(aStr)
print(bStr)

# int (integer)
# can only store integers--not other types of numbers
anInt = 98 # this is an integer
print(type(anInt)) # <class 'int'>
# int = 7 don't do this since int is a python keyword


# float (float)
# can store decimals
aFloat = 13.2
print(type(aFloat)) # <class 'float'>

# you can perform math operations with floats and ints together
print(anInt + aFloat)


# bool (boolean)
# booleans have one of two values: True or False
aBool = True # must be capital T
anotherBool = False
print(type(aBool)) # <class 'bool'>
print(anotherBool)


# === Converting/casting
# we can "cast" (convert) one data type to another when we need to ensure they are the
# same data type.
var1 = "1"
var2 = 2
# print(var1+var2) # doesn't work because they are different data types

# we can "cast" (convert) one data type to another to ensure they are the same data type
x = int(var1) # converts var1 into an int and stores that int in the variable x
print(type(var1)) # var1 is left unchanged and is still a string
print(type(x)) # x however is an integer
print(var1) # prints 1
print(x) # also prints 1 but be careful var1 and x are different datatypes


print(x+var2)
print(int(var1)+var2)

print(var1+str(var2)) # adding two strings is concatenation # this gives "12"

x = "hello"
y = "world"
print(x+y) # helloworld
"""
COMMON TYPE CASTING FUNCTIONS:
int(): Converts a value to an integer.
float(): Converts a value to a floating-point number.
str(): Converts a value to a string.
bool(): Converts a value to a boolean. # converts the number 1 to True and 0 to False

# ALSO COMMON BUT WE WILL LEARN LATER:
list(): Converts a value to a list.
tuple(): Converts a value to a tuple.
set(): Converts a value to a set.
dict(): Converts a sequence of key-value pairs to a dictionary.
"""

# === Expressions
# an expression is a combination of values, variables, operators, 
# and function calls that are evaluated to produce a new value.

# + sum or concatenation
var1 = 10+30 # the 10+30 is an expression this is addition of nums
var2 = "hello"+ " " + "world" # concatenation of strings
print(var1)
print(var2)
# - subtraction
var1 = 7
var2 = 9
print(var1-var2)

# * multiplication
print(var2*var1)

# / division (will ALWAYS give back a float)
print(var1/var2)

# // floor division (used for integers)
print(var1//var2) # 0
print(var2//var1) # 1

# % modulo operation (remainder of integer division)
print(5%2) # read as 5 mod 2
print(2%5)


# ** exponentiation
print(2**5) # 32
print(8**(1/3)) # 2.0

# === Order of operations is going to be P E MD AS
# (same tier operations are performed left to right)
# parentheses are the only grouping symbol don't use brackets they are for other things

# Example: Calculating the average temperature for today
minTemp = 85
maxTemp = 120
avgTemp = (minTemp+maxTemp)/2
print(avgTemp)

# Example: Calculating the volume of water in a cylinder
height = 8
radius = 3.5
pi = 3.14
area = pi * radius**2
volume = area * height
print(volume)

# === Collecting user input using the input() function
# we'll talk more about functions later on.


# Example: Writing a script that asks how many popsicles
# a user wants and tells them the total cost.

price = 4.0
tax = 0.1
tip = 0.25

nPops = input("How many popsicles would you like? ")
print(type(nPops)) # this is a string we should cast it to an int

total = price * int(nPops) * (1 + tip + tax)
print("Your order toal is $" + str(total))