# === 0. f-strings

print("f-strings: ")
# f-strings provide a concise and readable way to include 
# expressions inside string literals, using curly braces {}.
# format f"stringstuf {x}more string stuff" where x is some variable

# create a variable for your name and another for your age
# print out: "Hello, my name is {name} and I am {age} years old."
name = 'ronnie'
age = 36
greeting_str = f'Hello, my name is {name} and I am {age} years old.'
print(greeting_str)

# or we could have just printed directly:
print(f'Hello, my name is {name} and I am {age} years old.')
# === Iteration
'''
iteration - a way to do something over and over again in code
repeatedly run a snippet of code
'''

# === While loop: while some condition is True, keep running
# this piece of code
print("While Loops: ")
"""
3 key ingredients:
    - Initialization
    - Terminating condition
    - Moving towards terminating condition (typically)
"""


# Example: Printing hello n times

# initialization
n = 3
# terminating condition
while n > 0: # while 3 > 0: -> while True:
    print("hello")
    n -= 1 # approaching the terminating condition

def placeAnOrder():
    # initialization
    order = input("What would you like? ")
    while order != "Nothing else":
        print("{} coming right up!!".format(order))
        order = input("What else? ")

# placeAnOrder()
        
# === For loop:
print("\nFor Loops:")
# for each item in compoundDataType1
# for each part of a whole
# for each thing in a collection of things

# Example: Looping through a string and printing each
# character in a separate line

aStr = "Hello"
for char in aStr: # "H", "e", "l", "l", "o"
    # 1 -> char = "H"
    # 2 -> char = "e"
    # 3 -> char = "l"
    # ...
    print(char)

print("\nrange:")
# Example: Looping through a range of values
"""
three forms of range:
--note that range's stop value is exclusive
-- range is a built-in python function that returns an iterable starting at some value and ending at some value. 
"""

# you can think of range as internally being a sequence of numbers.
#range(1, 11, 2) #-> 1,3,5,7,9 
#range(5, 7) #-> 5,6
#range(3) # 0,1,2

# often we use range() with for loops to do an iteration a certain number of times.

for i in range(11):# -> start from 0, go all the way up to stop (non-inclusive)
    # i = 0, i = 1, i = 2, ..., i = 10
    print(i)


for j in range(1, 12): #-> start from start, go all the way up to stop (non-inclusive on stop)
     # j = 1, j = 2, j = 3, ... j = 11
    print(2*j)

for k in range(2, 8, 5):#-> start from start, go to stop by step size
    # k = 2, k = 7
    print(k)

# you can also go backwards if you use a negative step-size:
for m in range(100, 0, -5):
    # m = 100, m= 95, ... m= 5
    print(m)

print('\nFor Loops examples: ')
# === Counting with loops
# Example: counting the vowels in a string
def countVowels(aStr):
    count = 0    
    for char in aStr: # char = "h", char = "e", char = "l", ...
        if char in "AEIOUaeiou":
            count += 1
    return count
    
    # I need to visit every character -> loop!
    # count only the ones that are vowels -> conditional!
    # keep track of count

sentence = "hello"
print(f'There are {countVowels(sentence)} vowels in the word "{sentence}"')

sentence = "It is not raining outside"
print(f'There are {countVowels(sentence)} vowels in the word "{sentence}"')

# Example: building a string that contains only the lower case
# characters from another string
def keep_lower(sent):
    lower_sent = "" # start with an empty string
    for char in sent:
        if char in "abcdefghijklmnopqrstuvwxyz":
            lower_sent += char
    return lower_sent
sentence = "ThIS is FuN"
print(keep_lower(sentence))

# === Continue statement
print("\nContinue Examples: ")


# Example: cleaning data from a faulty sensor
def cleanData(aStr):
    # build a str without the hyphens
    # visit every char
    # check if it is a -
    newStr = ""
    for char in aStr: # char = "1", char = "2", char = "3", char = ","
        if char == "-":
            continue
        newStr += char
    return newStr

# === Break statement
print("\nBreak examples:")
# Example: write a function that returns the first position
# of a target letter on a string

def findPosition(aStr, char):
    # visit every character
    # check whether I found the char
    # keep track of its position
    position = 0
    for c in aStr: # c = "3", c = ",", ...
        if char == c: # if c == char:
            break
        position += 1
    return position
"""
anotherStr = "3,1,5,a,8"
print(findPosition(anotherStr,"1"))
"""

# Example: Write a function that decrypts the following message
# by keeping the characters located on indices divisible by 3

def decrypt(message):
    new= ""
    for k in range(0, len(message), 3):
        new +=message[k]
    return new
message = " ascdwooiolkl"
print(decrypt(message))

print("\nNested Loops: ")
# === Nested loops
# Example: Printing the pairs of numbers between 0 and n whose
# sum is divisible by 2.

def printEvenPairs(N):
    for i in range(N): # starts at 0, then does 1, then does 2
        for j in range(N): # this loop runs until completion, then goes back to outer loop
            if (i+j)%2 == 0:
                print(i,j)

printEvenPairs(3)