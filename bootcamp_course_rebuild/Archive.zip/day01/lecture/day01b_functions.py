"""
3. Functions
    a. Declaring
    b. Calling
    d. Parameters
    e. Returning vs printing
    f. Combining functions
"""

# === Functions: Why functions?

# Example: Calculating the volume of various bricks
w1 = 5
h1 = 10
l1 = 6
vol1 = w1*h1*l1

w2 = 2
h2 = 7
l2 = 8
vol2 = w2*h2*l2

w3 = 1
h3 = 2
l3 = 1
vol1 = w3*h3*l3

# seems like we are repeating code...
# maybe there is a better way...

# === Functions: Declaring and calling a function

# Example: Write a function that greets a customer


# defining or declaring
def greet():
    print("Welcome to King of Pops!")

# calling or executing
"""
greet()
greet()
greet()
greet()
greet()
"""

# Example: Write a function that asks a customer
# how many bubble teas they would like and tells
# them the total cost of their order.

def order():
    nTeas = input("How many bubble teas? ")
    price = 5.0
    print("Your total is $"+str(int(nTeas)*price))
"""
order()
order()
order()
"""

# === Functions: Parameters and arguments

# Follow-up: Calculating the volume of various bricks


def volBrick(w, h, l): # parameters
    print(w*h*l)

volBrick(1,2,3) # arguments
volBrick(3,4,5)


# Example: Write a function that takes as input
# the total number of cake layers and calculates
# the total cost of the cake

def cakeCost(nLayers):
    print("Your cake costs $"+str(nLayers*3.0))

cakeCost(5)

# === Functions: Scope

# Example: Writing a function that takes as input
# the radius, height and density of a cake and prints
# the total weight of the cake.

def cakeWeight(radius, height, density):
    volume = radius ** 2 * 3.14 * height
    weight = volume * density
    print(weight)


cakeWeight(2,3,1.2)
# both of these error because the volume variable defined above only exist
# within the scope of the function
# print(volume) 
# print(weight)


# === Functions: Return
#The return statement in Python is used in functions to exit the function
# and return a value to the caller.

# Example: Write a function that takes as input the
# amount of caffeine per volume in a drink and returns
# the total amount of caffeine contained in that drink.

# === Functions: Return
#The return statement in Python is used in functions to exit the function
# and return a value to the caller.

# Example: Write a function that takes as input the
# amount of caffeine per volume in a drink and returns
# the total amount of caffeine contained in that drink.


def caffeine(percent, vol):
    return percent*vol


caffeine1 = caffeine(.05,2)
caffeine2 = caffeine(.1,8)
print(caffeine1)
print(caffeine2)



# === Shortcut operators
# it is often the case that you will need to update the value of a variable

count = 0
count = count + 1 # count = 0 + 1
count = count + 5 # count = 1 + 5
print(count)

# since the above is so common, there are some shortcuts for these:
# +=

count2 = 10
count2 += 20
print(count2)

# also works with concatenating strings:
aStr = "Good "
aStr += "morning!"
print(aStr)

# -=

countDown = 50
countDown -= 4
print(countDown)

# *=

aNum = 45
aNum *= 0.5
print(aNum)

anotherStr = "hi!"
anotherStr *= 6
print(anotherStr)

# /=

anotherNum = 50
anotherNum /= 25
print(anotherNum)



# === Functions: Combining functions

# Example: Write a set of functions that calculates
# how much clay you will need to create a sculpture
# in a pottery class.
# the sculpture will contain a sphere of some radius, 
# a cube of some width
# and two cylinders that have the same radius but can differ from the sphere.

def sphVol(radius):
    return 4/3 * (radius**3) * 3.14

def cylVol(radius, height):
    return 3.14 * radius**2 * height

def cubeVol(width):
    return width**3

def sculptureVol(rSph, rCyl, h, w):
    vS = sphVol(rSph)
    vCy = cylVol(rCyl, h)
    vCu = cubeVol(w)
    return 2*vCy + vS + vCu

totalVol = sculptureVol(3, 4, 2, 7)
print(totalVol)

# >>> Day 2 Miniquiz - Functions

# === Functions: Builtin python functions

aNum = type(5.6) # the data type for that var/value
aResult = print(aNum) 
print(aResult)