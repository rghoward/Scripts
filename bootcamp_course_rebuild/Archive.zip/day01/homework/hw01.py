

"""
Homework 01: Python Basics with Alestorm Theme

Instructions:
1. Solve each problem by writing a function definition.
2. The function should perform the task described in the problem.
3. Make sure to test your functions to ensure they work correctly.
4. Submit your completed hw01.py file.

Good luck, and may the winds of the high seas be at your back!

Note: Each problem should be solved using a function definition. The function name and parameters are provided. You should only fill in the function body.
"""

# Problem 1: Dynamic Typing
# Write a function that returns the type of the given identifier.
# Example: identifier_type(5) should return <class 'int'>
def identifier_type(identifier):
    pass

# Problem 2: Type Coercion
# Write a function that converts the given number to a float and a string, then returns both.
# Example: type_coercion(3) should return (3.0, '3')
def type_coercion(number):
    pass

# Problem 3: Numerical Operators
# Write a function that raises a given number to the power of 6 and returns the result.
# Example: power_six(2) should return 64
def power_six(number):
    pass

# Problem 4: List Slicing
# Write a function that takes a list and returns a new list that is a slice of the original, from index 1 to 3.
# Example: slice_list(['Rum', 'Pirates', 'Treasure', 'Seas']) should return ['Pirates', 'Treasure']
def slice_list(lst):
    pass

# Problem 5: Dictionary Operations
# Write a function that takes a dictionary and a key, and returns the value associated with that key.
# Example: get_value({'Ship': 'Black Pearl', 'Captain': 'Jack Sparrow'}, 'Captain') should return 'Jack Sparrow'
def get_value(dct, key):
    pass

# Problem 6: in and not in Operators
# Write a function that checks if a given item is in a list.
# Example: is_in_list('Parrot', ['Sword', 'Parrot', 'Gold']) should return True
def is_in_list(item, lst):
    pass

# Problem 7: Importing Modules
# Write a function that uses the math module to return the sine of a given angle (in radians).
# Example: sine_angle(0.5) should return math.sin(0.5)
import math
def sine_angle(angle):
    pass

# Problem 8: String Operations
# Write a function that returns the uppercase version of a given string.
# Example: shout('Ahoy') should return 'AHOY'
def shout(string):
    pass

# Problem 9: Variable Reassignment
# Write a function that reassigns a variable within the function scope and returns the new value.
# Example: reassign_variable('Yo Ho Ho') should return 'A Pirate's Life for Me'
def reassign_variable(variable):
    pass

# Problem 10: Boolean Logic
# Write a function that returns True if the given string is not empty, otherwise False.
# Example: is_non_empty('Alestorm') should return True
def is_non_empty(string):
    pass
