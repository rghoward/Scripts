
"""
Homework 01 Solutions: Python Basics with Alestorm Theme
"""

def identifier_type(identifier):
    return type(identifier)

def type_coercion(number):
    return (float(number), str(number))

def power_six(number):
    return number ** 6

def slice_list(lst):
    return lst[1:4]

def get_value(dct, key):
    return dct.get(key)

def is_in_list(item, lst):
    return item in lst

import math
def sine_angle(angle):
    return math.sin(angle)

def shout(string):
    return string.upper()

def reassign_variable(variable):
    variable = "A Pirate's Life for Me"
    return variable

def is_non_empty(string):
    return bool(string)
