# === Tuples: basics
print("\nTuples Basics: ")
print("---------------------------")
# tuples are non-homogeneous (can store anything)
# tuples are immutable (can't change after creation) compound data types
# structure (item1, item2, item3, ...)

tup1 = (True, 32.5, ':D', 'a phrase', [1,2])
tup2 = ("Hello", 55.0, True)
print(tup2)
tup5 = ("hi", 34, 0)
# tup5[-1] = 8 # this is not allowed since tuples are immutable!

print("\nTuples Empty and Single Elements: ")
print("---------------------------")
# empty or with a single element

# to create a tuple with one element, you must provide a comma after the 1st element
# this is because python has no way to differentiate between parentheses for expressions and tuples
# without the comma 
tup3 = (1,) # a single element tuple
tup4 = ("The holiday was great!",) # another
print(tup3)
print(type(tup4))

# for an emepty tuple, just use parentheses (no commas)
tup5 = ()
print(tup5)


print("\nTuples: Concatentation ")
print("---------------------------")
# concatenation
tup1 = ("The holiday was great!",)
tup1 += ("but it is time to go back to work :)",) # we are not changing the tuple, we are replacing it

tup1 = (0,2,3)
tup2 = (1,4,5)
tup3 = tup1 + tup2 # (0, 2, 3, 1, 4, 5)
print(tup3)

# the * makes repeated concatenations just like strings and lists
tup1 = (0,2,3)
tup1 = tup1*3
print(tup1) # (0, 2, 3, 0, 2, 3, 0, 2, 3)


print("\nTuples: Iteration: ")
print("---------------------------")

# building a tuple iteratively
tup7 = ()
for i in range(11):
    tup7 += (i,) # remember the tup7 isn't being updated, it is continually being replaced
print(tup7, "\n")



# iterating through a tuple and doubling each value
for item in tup7:
    print(item*2)



# Example: Write a function that finds all indices of a
# target value in a tuple and returns them inside a new
# tuple.

def findAll(petTuple, target):
    newTup = ()
    for idx in range(len(petTuple)):
        if petTuple[idx] == target:
            newTup += (idx,)
    return newTup    


otherPets = ('cat', 'dog', 'cat', 'dog', 'bird', ['dog'])
pet = 'dog'
print("\n", findAll(otherPets,pet)) #> (1,3) a tuple with all of the indices


print("\nTuples: methods: ")
print("---------------------------")
# === Tuples: methods

# .count(val) method <- also works for lists
# counts how many times a value occurs in a list or tuple
# and RETURNS that value.
otherPets = ('cat', 'dog', 'cat', 'dog', 'bird', ['dog'])
nCats = otherPets.count("cat")
print(f"There are {nCats} cats")

# .index(val) <- also works for lists
# find the first location of a value in a list or tuple
# and RETURNS that value.
nums = (1, 5, 13, 13.0, 12.0, 12)
idx13 = nums.index(13)
print(f"13 is at location: {idx13}")

idx12 = nums.index(12)
print(f'The first occurence of 12 is at {idx12}')

# idx7 = nums.index(7) # Errors when the value is not in the tuple or list

# >>> Day 6 Miniquiz - Tuple basics


# === Tuples: unpacking
print("\nTuples: unpacking: ")
print("---------------------------")
# tuple unpacking allows you to assign the elements of a tuple to multiple variables in a single statement


a = 5
b = 8
c, d = (13, 20) # sometimes you'll see (c,d) = (13,20) instead both do same thing
print(c)
print(d)

# (e,f,g) = (1,0) # ValueError: not enough values to unpack (expected 3, got 2)

# NOTE you can also unpack lists the same way
# NOTE you can also unpack strings the samne way

a,b = [1,2]
print(a,b)
c,d ='34' # 1 2
print(c,d) # 3 4



# Example: Write a function that takes a tuple with two floats
# as input and swaps the two values if the second value is less
# than the first value

def swapAnB(tup):
    (a, b) = tup
    if b < a:
        return (b, a)
    else:
        return (a, b)

print(swapAnB((9,10)))




# === Tuples: enumerate
print("\nenumerate() ")
print("---------------------------")
# enumerate allows you to iterate over a list (or iterable) and get both the index and value
tup = (5,7,9)
print(enumerate(tup)) # an enumerate object
# if we cast to a list, then we get a list of tuples
print(list(enumerate(tup))) # the first val in each tuple is the index of the 2nd val in tup above

for idx, val in enumerate(tup): # unpack the enumerate object as you iterate
    print(idx, val)

# Example: Write a function that takes a str as input and
# stores the index of all vowels inside a list.
    
def indexVowels2(aStr):
    outList = []
    for (i,char) in enumerate(aStr):
        if char in "aeiouAEIOU":
            outList.append(i) # outList += [i]
    return outList


phrase = "What a WILD storm!"
print(indexVowels2(phrase))