# === Dictionaries
print("Intro to Dictionaries: ")
# a dictionary is a collection of key-value pairs, where each key is 
#unique and used to access its corresponding value. Dictionaries are mutable, 
#meaning they can be changed after they are created. 

# creating a dictionary
# {key : value}
aDict = {"x2r": 15, "z3r": 20, "y34s": 30}

# accessing a dictionary
print(aDict["z3r"])

# Example: Finding how much of a product is available
# using a dictionary
print(aDict["y34s"])
#print(aDict["hello"]) # not in dictionary!! error!

print("\nCreating and Accessing Dictionaries: ")
# dict key > unique immutable datatype: int, a float, bool,
# NoneType or a tuple, a str
bDict = {None: 67, (1,2): 3, 4:89}

print(bDict)
print(bDict[None] + bDict[4] + bDict[(1,2)])
cDict = {1:1, 3: 9, 1:4} # notice that 1 is mapped to 4, not 3.  You may also notice that the print order differs from creation
print(cDict)

# reassigning dictionary values
bDict[None] = 43

print(bDict)

new_dict = {} # empty dict
new_dict[1] = 2 # adding a new k,v pair
print(new_dict)

# building a dictionary from an empty one
newDict = {}
for i in range(4):
    newDict[i] = i**2

print(newDict)

# Example: Creating a dictionary with Dua Lipa's songs
# from Future Nostalgia

dua = {}
dua["Levitating"] = 900
dua["Physical"] = 700
dua["Hallucinate"] = "300 million"
print(dua)

# chained indexing with dictionaries
print(dua["Hallucinate"][1])

# removing dictionary value

del dua["Physical"]
print(dua)

# === Iterating through dictionaries
aDict = {'x2r':15,'z3r': 20,'y34s':30}
# looping over keys

for key in aDict.keys():
    print(key)
    print(aDict[key])

print("\n")

for something in aDict:
    print(something)
    print(aDict[something])

# looping over values
for v in aDict.values():
    print(v)
    #print(aDict[v]) # cannot access key from value!

# looping over items
for (k, v) in aDict.items():
    print(k,v)

# === Extracting information using dictionaries
print("\nExtracting information from dicts: ")

# Example: given a string, let us build a dictionary
# in which the word is the key and the corresponding
# value is the number of times the word shows up on
# that string (i.e. the absolute frequency)

def wordCount(aStr):
    aList = aStr.split()
    countDict = {}
    for word in aList:
        if word in countDict:
            countDict[word] += 1
        else:
            countDict[word] = 1
    return countDict

sentence = "rain on me rain on me rain on me me me me me"
print(wordCount(sentence))

# Example: given a dictionary with information about
# stocks, where each key is a stock and value is a
# tuple = (price, qty, change). Put together a list
# of stocks that have earned you more than $5k in the
# past day.

def gettingRich(aDict):
    newList = []
    for (key,value) in aDict.items():
        price = value[0]
        qty = value[1]
        change = value[2]
        money = price*qty*change
        if money > 5000:
            newList.append(key)
    return newList
stockDict = {"apple":(1000, 1000, 0.1),"gamestop":(500, 100, 2.5),
"google":(5000, 10, .05)}
print(gettingRich(stockDict))