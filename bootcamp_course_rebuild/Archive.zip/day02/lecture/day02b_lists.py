# === Lists
print("\nLists:")
print("---------------------------")
# non-homogenous sequence of items
# lists are mutable meaning they can be changed
# in python, lists can contain any type of data as well as mixed data types
# don't name a list list because list is an internal python keyword

aList = ['cat', 'dog', 'iguana', 'bird', True, 13.5, 0]
print(aList)

# we can iterate through the list for item in list
for item in aList:
    # both of these print the same thing
    print(f'{item} has type {type(item)}') # f string
    print('{} has type {}'.format(item, type(item))) # .format 

# we can access lists by index
print(aList[-1]) # prints the last item
print(aList[0]) # prints first item

# we can also iterate using indices
for i in range(len(aList)):
    print(aList[i])

print("\nList Slicing:")
print("---------------------------")
# slicing
# slicing works the same with lists as it doesn strings, except you slice the items at given indices. 
animalsList = aList[0:4] # creates a list from aList above
print(animalsList)

# we can reverse a list using slicing:
print(animalsList[::-1])

print("\nNested Indexing:")
print("---------------------------")
# nested indexing
# the practice of accessing elements that are contained within nested or hierarchical data structures, such as lists of lists,
# to get cat from animalList, I would do animalsList[0] because cat is the first item in the list
# if I want to get the first character of the word cat, I would do animalsList[0][0]
print(animalsList[0][0])

# lists can contain any type of object
# a list is an object
# so a list can contain a list
list_of_objects = ["a", [1,2,3], [[1]], 2]

# how could I get the 2 in the list above?
print(list_of_objects[1][1]) # accesses the list at index 1, then gives the 2 in the inner list stored at index 1

# how could I get the 1 in the 2nd list in the list above?
print(list_of_objects[2][0][0])

print("\nMutability:")
print("---------------------------")
# mutability
# lists are mutable meaning they can be changed
new_list = ['1', 7, [1,2,3], True]

new_list[2][0] = "one"
print(new_list)

new_list[2] = "123" # remember you cannot do this with strings since they are immutable
print(new_list)

# concatenation
print("\nConcatenation:")
print("---------------------------")
list1 = [1, 5, True]
list2 = [True, 5, 1]
list3 = list1 + list2
list4 = list2 + list1

print(list3)
print(list4)

# we can do repeated concatenation of the same list using multiplication just like with strings
print(list1*3)

# in for lists
print("\nin examples")
print("---------------------------")
my_list = [1,3,False, [1]]

print(1 in my_list) # True
print(False in my_list) # True
print([1] in my_list) # True
print([2] in my_list) # False
print(True in my_list) # True because the integer 1 is interpreted as True (would also be true if 1.0 was there but not '1')

print("\nSome List Function Examples: ")
print("---------------------------")
# Example: Write a function that takes in a list
# and calculates the total cost of your shopping cart.

def costCart(aList):
    total = 0.0
    for i in range(0, len(aList), 3): # i = 0, i = 3, i = 6, etc.
        qty = aList[i+1] # i+1 = 1, 4, 7
        cost = aList[i+2] # i+2 = 2,5, 8
        total += qty*cost
    return total

# first thing is the object, 2nd thing is the number of that object, the 3rd thing is the price of that object
shopList = ['Babybell',16,.60,'Cashews',1,14.99, 'Kinder', 4, 6.0]
print(costCart(shopList)) # > 24.59

# === Adding elements to a list
print("\nAdding Elements to a List")
print("---------------------------")
# .append() -> returns None, but changes the original list
# .append() allows us to add items at end of list
cList = [1, 'g', 'j', 89.0, False]
cList.append('Hello')
print(cList) # notice that cList changed in place because .append() changes the current list (returns None)

# can we store cList.append() in a new variable?
val1 = cList.append('True') # You shouldn't do this. because .append() returns None
print(val1) # None because .append() returns None.
# However, did cList change again?
print(cList) # yes it did

if cList.append(1):
    print("did this work?")
else:
    print("it did not") # this one is printed becaused .append() returns None which is falsy
# however, the 1 was appended to cList
print(cList)

# another way to apppend (technically not appending, it is concatenating and storing the concatenation into the same var)
# +=
dList = [0]
dList += ["j"]
dList += ['hi']
dList += "that" # what you are doing is += ['t','h','a','t']
# the above is the same as casting a string to a list and concatenating
dList += list("that") # same thing as line above

# Example: Write a function that takes in a list of sublists
# [pet1, pet2, ...]. Your function should output a list with
# the count of pets that correspond to the target pet.


def manyPets(listPets, targetPet):
    countList = []
    for subList in listPets:
        count = 0 # count will be reset to 0 for each new sublist
        for pet in subList:
            if pet == targetPet:
                count += 1
        countList += [count]
        # countList.append(count) also works <- my preferred way
    return countList
   
listOfPets = [['dog','dog','cat'],['bird','fish'],['dog','fish']]
targetPet = 'dog'
print(manyPets(listOfPets, targetPet)) # > [2,0,1]

print("\nInserting items in a List:")
print("---------------------------")
# .insert(index, item) -> returns None
# inserts at the given index and moves the item currently there to the right.


bList = ['twix', 'bueno', 'lindt', 'godiva', 'hersheys']
bList.insert(1, "kisses")
print(bList)

# since .insert() returns None, you shouldn't do things like the below
print(bList.insert(4, 'dove')) # prints None but the list is updated
x = bList.insert(3, 'm&m') # x is now None because .insert returns None but bList is updated

# === Removing elements from a list
print("\nRemoving elements from a list:")
print("---------------------------")
# .remove(item) -> returns None
# if it exists, removes first occurrence, if not found, ERRORS

bList = ['twix', 'bueno', 'lindt', 'godiva', 'hersheys']
bList.remove('godiva')
print(bList) # ['twix', 'bueno', 'lindt', 'hersheys']
# bList.remove('godiva') # errors this time because we already removed it and it is no longer in list

cList = [0, 0, 1]
cList.remove(0) # removes only one of the 0s
cList.remove(0) # this is okay because there is still one 0 left
print(cList)

# === Miscellaneous list methods
print("\nReverse a List:")
print("---------------------------")
# .reverse() -> returns None

bList = ['twix', 'bueno', 'lindt', 'godiva', 'hersheys']
bList.reverse()
print(bList)




# .sort() -> returns None (list must be homogenous ie: same data types)
# .sort() sorts in place
print("\nsorted() vs .sort(): ")
print("---------------------------")

dList = [13, 15, 90, 21]
fList = ['party', 'in', 'the', 'usa', 'people']
dList.sort()
print(dList) # [13, 15, 21, 90]
fList.sort() # sorted alphabetically ['in', 'party', 'people', 'the', 'usa']
print(fList)


# sorted() function
# sorted() is a function not a method and sorted() does not change the list in place
# sorted() returns a new list
print("\nsorted() function)")
print("---------------------------")
dList = [13, 15, 90, 21, 2, 7]
sorted(dList) # returns a sorted list but did not sort the original
print(dList) # [13, 15, 90, 21, 2, 7]

sorted_dList = sorted(dList) # this will return a sorted list and store it in sorted_dList
print(sorted_dList) # this list is sorted

print(sorted(dList)) # this prints a sorted list since sorted() returns a sorted list


# Example: Write a function that returns the scores of the
# three best figure skaters in a competition given a list.

def podium(aList):
    # we will sort the list and get the top 3 scores
    aList.sort() # sorts in place
    aList.reverse() # now it goes from biggest to smallest
    return aList[0:3]

scores = [98, 95, 87, 100, 76]
print(podium(scores))