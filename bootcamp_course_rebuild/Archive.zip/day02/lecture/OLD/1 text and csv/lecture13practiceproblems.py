import csv
##########Practice Problems###########

# 1. Use the file countries.csv to calculate the average population of a country whose 
# name starts with an A.  You do not have to make this a function.
with open("countries.csv") as f:
    reader = csv.reader(f, delimiter=",", quotechar='"')
    lines = list(reader)[1:] # skip the header row
    sum = 0
    count = 0
    for item in lines:
        if item[0][0].lower() == 'a': #we are looking at first letter of first item
            sum += int(item[2]) # all items in list are strings so cast
            count += 1
    print(f"The average is {int(sum/count)}")

# 2. Create a new file called big_countries.csv that contains only the lines from 
# the countries.csv file that have a population over 50 million. You do not have 
# to make this a function. You should also include the header line in this new file.
with open("countries.csv") as f:
    reader = csv.reader(f, delimiter=",", quotechar='"')
    new_countries = [] # store countries in list
    for i,line in enumerate(reader): # we can iterate through lines in reader without casting reader as a list
        if i == 0:
            new_countries.append(line) # keep the header
        elif int(line[2]) > 50000000:
            new_countries.append(line) # keep countries with large population

with open("big_countries.csv", "w") as f:
    writer = csv.writer(f, lineterminator="\n")
    writer.writerows(new_countries)
    
# Create a new file called country_basics.csv that contains only the first four 
# columns and the column that gives you the GDP for that country from the countries.csv
# file. (5 columns total). You do not have to make this a function. You should also
# include the portions of the header line that are required. 
with open("countries.csv") as f:
    reader = csv.reader(f, delimiter=",", quotechar='"')
    lines = list(reader)
    header = lines[0][:4] + [lines[0][8]] # get first 4 columns in header row and 9 column
    data = []
    for item in lines[1:]:
        row = item[:4] + [item[8]]
        data.append(row)
        print(row)
with open("country_basics.csv", "w") as f:
    writer = csv.writer(f, lineterminator="\n")
    writer.writerow(header)
    writer.writerows(data)