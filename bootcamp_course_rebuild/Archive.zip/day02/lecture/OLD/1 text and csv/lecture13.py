import csv

def read_example1():
    f = open("example.txt")
    text = f.read()
    print(text)
    f.close()
# read_example1()
#### or

def read_example2():
    # using with open automatically closes the file for you
    with open("example.txt") as f: 
        # text = f.read() # reads in file as a giant string

        # using readline() is great when your file has a header and you want to grab it
        # it will read up to and include the end of line marker (\n)
        line_of_text = f.readline() # there'll be nothing to read unless you comment out f.read() above
        print(line_of_text)

        # you can use readlines() to get a list of all lines as a string (however, if you've used readline above, then it'll only get the 2nd - end lines)
        # notice below that the header is not printed again since we "grabbed" it from the file when we did f.readline() above
        lines = f.readlines()
    # all file reading has to be done within the "with" statement but other variables defined within the with statement can be used later.
    for i,line in enumerate(lines):
        print(i, line)
# read_example2()

def write_example():
# we can write to files use w or a permission
# let's make a new file and write to it
# using the paramater "w" will fully overwrite the existing file.  use "a" if you want to append to an existing file isntead
    with open("example2.txt", "w") as outfile:
        outfile.write("line1\nline2\nline3")
# write_example()

def append_example():
    # if you use the 'a' permission and the file does not exist, it'll create a new file.
    # don't forget to use \n to make new lines
    with open("example2.txt", "a") as outfile:
        outfile.write("line1\nline2\nline3")
# append_example()

# Write a function that takes in two filenames as parameters, reads the text from the first file and writes it back out to the second file removing all punctuation.
def remove_punctuation(input_file, output_file):
    with open(input_file) as file1:
        input = file1.read()
    with open(output_file, "w") as file2:
        output = ""
        for symbol in input:
            if symbol.isalpha() or symbol.isdigit() or symbol.isspace():
                output += symbol
        file2.write(output)

# remove_punctuation("course_schedule.txt", "course_schedule_clean.txt")

# Write a function that uses the data from airtravel.csv to calculate the average number of transatlantic passengers per month for the year 1960 in thousands of passengers.
def avg_num_per_month(input_file_name):
    with open(input_file_name) as f:
        f.readline() # get rid of the first line as it is a header
        lines = f.readlines()
    sum = 0
    for line in lines:
        columns = line.split(",")
        print(columns[-1])
        try:
            sum += int(columns[-1].strip())  
        except:
            pass # if our line above is blank then an exception will occur which we will skip
    avg = sum / len(lines)
    print (f"The average is: {round(avg,2)}")

# avg_num_per_month("airtravel.csv")

def csv_reader():
## csv reader
    with open('airtravel.csv') as f:
        reader = csv.reader(f, delimiter = ",", quotechar='"')
        print(reader)
        reader_list = list(reader) #cast the reader to a list
        print(reader_list) # each item in list is a list corresponding to the row

# csv_reader()

def csv_writer():
    # showcasing csv.writer()
    data = [["row1data1", "row1data2"], ["row2data1", "row2data2"]] # 2 rows of data to write
    headers = ["headerdata1", "headerdata2"] # a header with 2 columns

    with open("output.csv", "w") as fout:
        writer = csv.writer(fout, lineterminator = '\n')
        writer.writerow(headers)
        for line in data:
            writer.writerow(line)
        # or
        #writer.writerows(data)

# csv_writer()

def csv_dict_reader():
    # csv.DictReader
    # csv.DictReader maps the information in each row to a dict
    # the keys to the dict will be the first row in the csv file
    # if you don't want that, then you have to specify fieldnames paramater shown in next example
    with open("airtravel.csv") as csvfile:
        reader = csv.DictReader(csvfile)
        print(reader.fieldnames) # shows the keys (fields from first row of file)
        for row in reader:
            print(row)
# csv_dict_reader()


def csv_dict_reader2():
    # csv.DictReader
    # csv.DictReader maps the information in each row to a dict
    # the key to the dict will be the first row in the csv file
    # if you don't want that, then you have to specify fieldnames paramater
    with open("airtravel.csv") as csvfile:
        reader = csv.DictReader(csvfile, fieldnames=['a','b', 'c', 'd'])
        print(reader.fieldnames) # ['a','b', 'c', 'd'] from above
        for row in reader:
            print(row)
# csv_dict_reader2()


def csv_dict_writer():
    # csv.DictWriter
    with open('names.csv', 'w', newline='') as csvfile:
        fieldnames = ['first_name', 'last_name'] # these will be the headers
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerow({'first_name': 'Baked', 'last_name': 'Beans'})
        writer.writerow({'first_name': 'Lovely', 'last_name': 'Spam'})
        writer.writerow({'first_name': 'Wonderful', 'last_name': 'Spam'})

csv_dict_writer()