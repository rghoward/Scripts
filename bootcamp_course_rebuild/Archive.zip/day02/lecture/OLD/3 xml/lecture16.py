import xml.etree.ElementTree as ET
tree = ET.parse('country_data.xml') # opens up and parses the xml file
root = tree.getroot() # grabs the root of the tree
print(root)
for child in root:
    print(child.tag, child.attrib) # you'll notice below that the attributes are stored in a dictionary
    # prints
    # country {'name': 'Liechtenstein'}
    # country {'name': 'Singapore'}
    # country {'name': 'Panama'}

    ### uncomment below to see nested children
    # we can also loop through children of the child above
    for grandchild in child:
        print(grandchild.text) # will print text if any is contained
        print(grandchild.attrib) # some of our tags have multiple attributes

# we can also access specific children by indexing
my_child = root[1]
print(my_child.attrib)

my_grandchild = root[2][0]
print(my_grandchild.text)
