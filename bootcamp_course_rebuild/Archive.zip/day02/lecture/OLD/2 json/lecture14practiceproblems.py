import json

def return_JSON_keys(filename):
    try:
        adict = json.load(open(filename))
        print(type(adict))
        return list(adict.keys())
    except:
        return None

print(return_JSON_keys("book.json"))
print(return_JSON_keys("airtravel.csv"))