import json

astr = '{"cat":3,"dog":4}' # notice the json code passed was a string
adict = json.loads(astr)
print(adict)


adict = json.load(open("book.json")) # if our json is stored in a file, we can load it
print(adict)


# we can convert a python dictionary to a JSON string
bdict = {"cat":None,"dog":4}
newstr = json.dumps(bdict)
print(newstr)
print(type(newstr))

# json.dump(bdict,open("newbook.json","w"))

# from pprint import pprint #import only 1 function from the pprint module 
# cdict = json.load(open("schedule.json"))
# print(cdict)
# pprint(cdict)

# import math
# print(math.floor(7.777))