# === Tuples: basics
print("\nTuples Basics: ")
print("---------------------------")
# tuples are non-homogeneous (can store anything)
# tuples are immutable (can't change after creation) compound data types
# structure (item1, item2, item3, ...)

tup1 = (True, 32.5, ':D', 'a phrase', [1,2])
tup2 = ("Hello", 55.0, True)
print(tup2)
tup5 = ("hi", 34, 0)
# tup5[-1] = 8 # this is not allowed since tuples are immutable!

print("\nTuples Empty and Single Elements: ")
print("---------------------------")
# empty or with a single element
a = (1)
print(a)
# to create a tuple with one element, you must provide a comma after the 1st element
# this is because python has no way to differentiate between parentheses for expressions and tuples
# without the comma 
a = (1,)
print(a)

# if you want an empty tuple, you just use parentheses without commas
b = ()
print(b)
print(type(b))

print("\nTuples: Concatentation ")
print("---------------------------")
# concatenation
tup1 = ("The holiday was great!",)
tup1 += ("but it is time to go back to work!",) # again, we didn't change the tuple, we created a new one with concatenation

tup1 = (0,2,3)
tup2 = (1,4,5)
tup3 = tup1 + tup2
print(tup3)

# the * makes repeated concatenations just like strings and lists
tup1 = (0,2,3)
tup2 = tup1 * 3
print(tup2)



print("\nTuples: Iteration: ")
print("---------------------------")

# building a tuple iteratively
tup7 = ()
for i in range(11):
    tup7 += (i,)
print(tup7)

print(range(10))
a = list(range(10))
print(a)

# iterating through a tuple and doubling each value
for item in tup7:
    print(item * 2)



# Example: Write a function that finds all indices of a
# target value in a tuple and returns them inside a new
# tuple.

def findAll(petTuple, target):
    new_tup = ()
    for i in range(len(petTuple)):
        if petTuple[i] == target:
            new_tup += (i,)  
    return new_tup

otherPets = ('cat', 'dog', 'cat', 'dog', 'bird', ['dog'])
pet = 'dog'
print("\n", findAll(otherPets,pet)) #> (1,3) a tuple with all of the indices


print("\nTuples: methods: ")
print("---------------------------")
# === Tuples: methods

# .count(val) method <- also works for lists
# counts how many times a value occurs in a list or tuple
# and RETURNS that value.
otherPets = ('cat', 'dog', 'cat', 'dog', 'bird', ['dog'])
n_cats = otherPets.count('cat')
print(f'There are {n_cats} cats.')

# .index(val) <- also works for lists
# find the first location of a value in a list or tuple
# and RETURNS that value.
nums = (1, 5, 13, 13.0, 12.0, 12)

idx_13 = nums.index(13)
print(f'13 is at location {idx_13}')

idx_12 = nums.index(12)
print(idx_12) # prints 4 which is 12.0 b/c it doesn't differentiate between ints and floats

# idx_7 = nums.index(7) errors b/c 7 is not in the tuple
if 7 in nums:
    idx_7 = nums.index(7)

# === Tuples: unpacking
print("\nTuples: unpacking: ")
print("---------------------------")
# tuple unpacking allows you to assign the elements of a tuple to multiple variables in a single statement
x = (1,2,3)
a = x[0]
b = x[1]
c = x[2]

e,f,g = (1,2,3)
print(f)


# NOTE you can also unpack lists the same way
a,b = [1,2]
print(a,b)

# NOTE you can also unpack strings the samne way
c,d = "ab"
print(c,d)

(c,d) = (1,2) # alt. way to unpack
print(c)

# NOTE be careful with unpacking
# you must have the same number of variables as elements in tuple when unpacking
# (e,f,g) = (1,2) # ValueError: not enough values to unpack (expected 3, got 2)
# e,f = (1,2,3) # ValueError: too many values to unpack (expected 2)


# Example: Write a function that takes a tuple with two floats
# as input and swaps the two values if the second value is less
# than the first value

def swapAnB(tup):
    a,b = tup
    if a < b:
        return (b,a)
    else:
        return (a,b)

print(swapAnB((9,10)))


def fun():
    return 7,4

a,b = fun()
print(a)
print(b)

c = fun()
print(c) # (7,4)
a = c[0]
b = c[1]

# === Tuples: enumerate
print("\nenumerate() ")
print("---------------------------")
# enumerate allows you to iterate over a list (or iterable) and get both the index and value
tup = (5,7,9)

print(enumerate(tup)) # an enumerate object
print(list(enumerate(tup)))

tup = ('a', 'b', 'c')
for idx, val in enumerate(tup):
    print(idx, val)

# Example: Write a function that takes a str as input and
# stores the index of all vowels inside a list.
    
def indexVowels2(aStr):
    vowel_list = []
    for i, c in enumerate(aStr):
        if c in 'aeiouAEIOU':
            vowel_list.append(i)
    return vowel_list

phrase = "What a WILD storm!"
print(indexVowels2(phrase))