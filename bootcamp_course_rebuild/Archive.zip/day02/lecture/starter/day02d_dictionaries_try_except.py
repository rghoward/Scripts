# === Dictionaries
print("Intro to Dictionaries: ")
# a dictionary is a collection of key-value pairs, where each key is 
# unique and used to access its corresponding value. Dictionaries are mutable, 
# meaning they can be changed after they are created. 

# creating a dictionary
# {key : value}
aDict = {"x2r": 15, "z3r": 20, "y34s": 30}

# accessing a dictionary
print(aDict['z3r'])

# print(aDict['hi']) # KeyError: 'hi'



print("\nCreating and Accessing Dictionaries: ")
# dict key > unique immutable datatype: int, a float, bool,
# NoneType or a tuple, a str
bDict = {None: 67, (1,2): 3, 4:'a'}

print(bDict)

# reassigning dictionary values
c_dict = {'a': 1, 'b': 7, None: None}
c_dict[None] = "something else"
print(c_dict)
print(c_dict[None])

some_dict = {1:1, 1:2, 1:3}
print(some_dict) # {1: 3}


new_dict = {} # empty dict
new_dict[1] = 7 # add a new k:v pair
print(new_dict)

# building a dictionary from an empty one
new_dict = {}

for i in range(4):
    new_dict[i] = i**2
print(new_dict)


# Example: Creating a dictionary with Dua Lipa's songs
# from Future Nostalgia
dua = {}
dua["Levitating"] = 900
dua["Physical"] = 700
dua["Hallucinate"] = "300 million"
print(dua)

# chained indexing with dictionaries
print(dua["Hallucinate"][1])

# removing dictionary value
del dua["Physical"]
print(dua)


# === Iterating through dictionaries
aDict = {'x2r':15,'z3r': 20,'y34s':30}

# looping over keys
for key in aDict.keys(): # aDict.keys() returns a list of keys in the dict
    print(key)
    print(aDict[key])

print("\n")
aDict = {'x2r':15,'z3r': 20,'y34s':30}

for something in aDict: # if you want to iterate over keys, you can just do this instead.
    print(something)
    print(aDict[something])

# looping over values
aDict = {'x2r':15,'z3r': 20,'y34s':30}

for v in aDict.values():
    print(v)

# looping over items
aDict = {'x2r':15,'z3r': 20,'y34s':30}

for k, v in aDict.items(): # .items() returns a list of k,v pairs
    print(k,v)

# === Extracting information using dictionaries
print("\nExtracting information from dicts: ")

def count_letters(a_str):
    new_dict = {}
    for letter in a_str:
        if letter in new_dict.keys():
            new_dict[letter] += 1
        else:
            new_dict[letter] = 1
    return new_dict

my_str = "askdlfjhakdghajksfjddklsajfoieqwfncklajfckldsjflaksdfjlkdsjf"
print(count_letters(my_str))

# Example: given a string, let us build a dictionary
# in which the word is the key and the corresponding
# value is the number of times the word shows up on
# that string (i.e. the absolute frequency)

def wordCount(aStr):
    str_list = aStr.split()
    count_dict = {}
    for word in str_list:
        if word in count_dict:
            count_dict[word] += 1
        else:
            count_dict[word] = 1
    return count_dict

sentence = "rain on me rain on me rain on me me me me me"
print(wordCount(sentence))

# Example: given a dictionary with information about
# stocks, where each key is a stock and value is a
# tuple = (price, qty, change). Put together a list
# of stocks that have earned you more than $5k in the
# past day.

def gettingRich(aDict):
    new_list = []
    for company, info_tup in aDict.items():
        price, qty, change = info_tup
        money = price * qty * change
        if money > 5000:
            new_list.append(company)
    return new_list

stockDict = {"apple":(1000, 1000, 0.1),"gamestop":(500, 100, 2.5),"google":(5000, 10, .05)}
print(gettingRich(stockDict))

# my email is rhoward46@gatech.edu