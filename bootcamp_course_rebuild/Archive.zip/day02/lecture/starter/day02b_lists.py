# === Lists
print("\nLists:")
print("---------------------------")
# non-homogenous sequence of items
# lists are mutable meaning they can be changed
# in python, lists can contain any type of data as well as mixed data types
# don't name a list list because list is an internal python keyword

aList = ['cat', 'dog', 'iguana', 'bird', True, 13.5, 0]
print(aList)

# we can iterate through the list for item in list
for item in aList:
    print(f'{item} has {type(item)}')

# we can access lists by index
print(aList[2])

# we can also iterate using indices
for i in range(len(aList)):
    print(aList[i])

print("\nList Slicing:")
print("---------------------------")
# slicing
# slicing works the same with lists as it doesn strings, except you slice the items at given indices. 
animal_list = aList[0:4]
print(animal_list)

# we can reverse a list using slicing:
rev_animals = animal_list[::-1]
print(rev_animals)
print(animal_list)

print("\nNested Indexing:")
print("---------------------------")
# nested indexing
# the practice of accessing elements that are contained within nested or hierarchical data structures, such as lists of lists,
# to get cat from animalList, I would do animalsList[0] because cat is the first item in the list
# if I want to get the first character of the word cat, I would do animalsList[0][0]

# lists can contain any type of object
# a list is an object
# so a list can contain a list
list_of_objects = ["a", [1,2,3], [[7]], 5]

# how could I get the 2 in the list above?
print(list_of_objects[1][1])

# how could I get the 7 in the 2nd list in the list above?
print(list_of_objects[2][0][0])

print("\nMutability:")
print("---------------------------")
# mutability
# lists are mutable meaning they can be changed
new_list = ['1', 7, [1,2,3], True]

new_list[0] = "one"
print(new_list)

new_list[2][0] = 4 # you cannot do this with strings since they are immutable.
print(new_list)

# concatenation
print("\nConcatenation:")
print("---------------------------")
list1 = [1, 5, True]
list2 = [True, 5, 1]
list3 = list1 + list2
list4 = list2 + list1

print(list3)
print(list4)

# list5 = list1 + 7 # this does not work
list5 = list1 + [7]
print(list5)

# we can do repeated concatenation of the same list using multiplication just like with strings
print(list1*3)


# in for lists
print("\nin examples")
print("---------------------------")
my_list = [1,3,False, [1]]

print(1 in my_list) # True
print(False in my_list) # True
print([1] in my_list) # True
print([2] in my_list) # False
print(True in my_list) # True because the integer 1 is interpreted as True (would also be true if 1.0 was there but not '1')

print("\nSome List Function Examples: ")
print("---------------------------")

# Example: Write a function that takes in a list
# and calculates the total cost of your shopping cart.
def costCart(aList):
    total = 0.0
    for i in range(0, len(aList), 3): # 0, 3, 6, ...
        qty = aList[i+1]
        cost = aList[i+2]
        total += qty*cost
    return total

# first thing is the object, 2nd thing is the number of that object, the 3rd thing is the price of that object
shopList = ['Babybell',16,.60,'Cashews',1,14.99, 'Kinder', 4, 6.0]
print(costCart(shopList)) # > 48.59

# === Adding elements to a list
print("\nAdding Elements to a List")
print("---------------------------")
# .append() -> returns None, but changes the original list
# .append() allows us to add items at end of list
cList = [1, 'g', 'j', 89.0, False]
cList.append("my tooth hurts!")
print(cList)

print(cList.append("because I got a root canal")) # print None b/c .append() returns None
print(cList)

# falsy values: 0, [], "", None, False, anything else that is empty
# truthy value is anything else: 1, -1, 'hi', 'False', or anything that is not empty
if cList.append("hi"):
    print("This won't print")

print(cList)

if [1234,1234]:
    print('goodbye')

def check(a_list):
    if a_list: # will only be True if something is in the list.
        for item in a_list:
            print(item)
    

# another way to append (technically not appending, it is concatenating and storing the concatenation into the same var)
# +=
dList = [0]
dList += ['j'] # this performs concatenation but looks like appending.
dList += ["hi"]
dList += "that"
print(dList) # [0, 'j', 'hi', 't', 'h', 'a', 't']
print(list("hello"))

# Example: Write a function that takes in a list of sublists
# [pet1, pet2, ...]. Your function should output a list with
# the count of pets that correspond to the target pet.


def manyPets(listPets, targetPet):
    count_list = []
    for sub_list in listPets:
        count = 0
        for pet in sub_list:
            if pet == targetPet:
                count += 1
        count_list.append(count)
    return count_list
   
listOfPets = [['dog','dog','cat'],['bird','fish'],['dog','fish']]
targetPet = 'dog'
print(manyPets(listOfPets, targetPet)) # > [2,0,1]

print("\nInserting items in a List:")
print("---------------------------")
# .insert(index, item) -> returns None
# inserts at the given index and moves the item currently there to the right.


bList = ['twix', 'bueno', 'lindt', 'godiva', 'hersheys']
bList.insert(1, "kisses")
print(bList)

# again, since .insert() returns None, you probably don't want to do things like this
print(bList.insert(4,'dove'))
x = bList.insert(3, 'm&m')
print(x)
print(bList)



# === Removing elements from a list
print("\nRemoving elements from a list:")
print("---------------------------")
# .remove(item) -> returns None
# if it exists, removes first occurrence, if not found, ERRORS

bList = ['twix', 'bueno', 'lindt', 'godiva', 'hersheys']
bList.remove('godiva')
print(bList)
# bList.remove('godiva') # this errors because, 'godiva' has already been removed and is not in list

cList = [0, 1, 0]
cList.remove(0)
print(cList)
cList.remove(0)
print(cList)

# === Miscellaneous list methods
print("\nReverse a List:")
print("---------------------------")
# .reverse() -> returns None

bList = ['twix', 'bueno', 'lindt', 'godiva', 'hersheys']
bList.reverse() 
print(bList)




# .sort() -> returns None (list must be homogenous ie: same data types)
# .sort() sorts in place
print("\nsorted() vs .sort(): ")
print("---------------------------")

dList = [13, 15, 90, 21]
dList.sort()
print(dList)

new_list  = [2, 1, 7, 3]
new_list.sort(reverse=True) # reverses the sorted list
print(new_list)

# sorted() function
# sorted() is a function not a method and sorted() does not change the list in place
# sorted() returns a new list
print("\nsorted() function)")
print("---------------------------")
dList = [13, 15, 90, 21, 2, 7]

sorted_dlist = sorted(dList, reverse=False)
print(sorted_dlist)
print(dList)




# Example: Write a function that returns the scores of the
# three best figure skaters in a competition given a list.

def podium(aList):
    aList.sort(reverse=True) # sorted largest to smallest
    return aList[:3]

scores = [98, 95, 87, 100, 76]
print(podium(scores))