# === String indexing
# string indexing allows access to individual characters in a string
# indexing starts at 0 (not 1)
# i.e to get the first character, you are getting the 0th character
print("\nString Indexing:")
print("-----------------------------------")

my_str = "Hello my name is Ronnie."

my_str[0] # gives me the first character of the string
my_str[5]
# my_str[100] # gives  an index error due to us trying to index too deep
print(my_str[-1]) # gives the last character


# length function: 
# gives the length of the string
len(my_str) # the len() function gives the length of the the sequence: list, string, etc.
print(len(my_str))

# to get last character of string:
my_str[len(my_str)-1] # one less than the length b/c indexing starts at 0
# my_str[len(my_str)] # errors, index error

# another way to get last character:
print(my_str[-1])

# === String iteration
print("\n String iteration:")
print("-----------------------------------")

# Example: looping through the indices vs looping through the characters

phrase = "Hope you have a great holiday!"
# for c in phrase:
#     print(c)

# recall that the stop value of range is exclusive
# thus if we want to print out each character, 
# we can use range(len(phrase)) since it will start at 0 inclusive and go to last index
phrase = "Hello!"
# for i in range(len(phrase)): # for i in range(6) -> for i in [0,1,2,3,4,5]
#     print(phrase[i]) 

# for i in range(len(phrase)):
#     print(str(i), phrase[i])


# === String immutability
print("\n String Immutability")
print("-----------------------------------")

# immutability means that the object cannot be changed after creation
# strings are immutable

# Example: Making the first letter of a sentence uppercase

sentence = "this class rocks!!!"
# sentence[0] = "T" # errors because strings are immutable.

# this works but not because we changed the string
# but because we changed what the variable sentence is referencing
sentence = "This class rocks!!!" 

 
# === String slicing
print("\nString slicing:")
# Basics (start:end, start:end:step)

test = 'Hope you enjoy the holiday!'
print(test[0:4]) # get the first character up through the character at index 3
print(test[0:7:2]) # 0, 2, 4, 6 <- characters at those indices
print(test[:10]) # if you don't put a start, then it defaults to 0
print(test[9:]) # starts at ninth character and goes through the end
print(test[::2]) # beginning to end in steps of 2
print(test[::-1]) # reverse string
print(test[:]) # copy of string

# Example: Getting pairs of characters out of a string
# print(letterPairs("spongebobs")) # -> sp-on-ge-bo-bs

def letterPairs(aStr):
    newStr = ""
    for i in range(0,len(aStr),2): # 0, 2, 4, ...
        pair = aStr[i:i+2] # aStr[0:2], aStr[2:4], 
        newStr += pair + "-"
    return newStr[0:len(newStr)-1]

print(letterPairs("spongebobs"))

# === String methods: .isupper(), .islower(), .isdigit(), .isalpha()
print("\nString methods:")
print("-----------------------------------")

# What is a method?
# a method is a function associated with some object
# methods can be thought of as a behavior of some object
# for example: len(my_str) is a function
# my_str.lower() a string has the ability to make itself lowercase


# aStr.methodName()

#.isupper() returns True if all letters are uppercase, False if not
aStr = "GOOD MORNING!!"
print(aStr.isupper()) #True 

bStr = "Good night"
print(bStr.isupper()) # False

cStr = "!!"
print(cStr.isupper()) # False b/c there are no capital letters.

#.islower() returns True if all letters are lowercase, False if not

dStr = "i am excited for lunch"
print(dStr.islower())

#.isdigit() returns True if all characters are digits, False if not
eStr = "4210 "
print(eStr.isdigit()) # False b/c there is a space at end
print("4210".isdigit()) # True

#.isalpha() returns True if all characters are letters, False if not
fStr = "acGbm"
print(fStr.isalpha()) # True


# Example: checking whether a password meets the following requirements:
# it has at least one upper case, one lower case and one digit

def checkPassw(password):
    has_lower = False
    has_upper = False
    has_digit = False
    for c in password:
        if c.isupper():
            has_upper = True
            continue
        if c.islower():
            has_lower = True
            continue
        if c.isdigit():
            has_digit = True
            continue
        print(c) # this would only run, if none of the conditions above are met.
    return has_lower and has_upper and has_digit


print(checkPassw("psd12"))
print(checkPassw("psdD"))
print(checkPassw("psdD321i "))


# === String methods: .upper(), .lower()

#.upper() returns upper case version of some str
phrase = "I can't wait for 4th of July!"
phrase_upper = phrase.upper()
print(phrase_upper)


#.lower() returns lower case version of some str
phrase_lower = phrase.upper().lower()
print(phrase_lower)

# Example: Counting how many birthdays in a given month
def howManyBdays(bdays, month):
    count = 0
    for i in range(0, len(bdays), 4):
        # we do steps by 4 since the beginning of each month is on a multiple of 4
        curr_month = bdays[i:i+3]
        if curr_month.lower() == month.lower():
            count += 1
    return count 

bdays = "Jan jun APR Jun May MAY may Feb mar"
month = "Jun"
print(f"There are {howManyBdays(bdays,month)} bdays in {month}")


# === String methods: .replace()


#.replace(substr, newsubstr) replaces all occurences of substr
# in a str with newsubstr


# Example: Making a recipe vegan

recipe = "2 eggs, 1 cup of flour, 1 cup milk, butter"
vegan_recipe = recipe.replace("eggs", "aquafaba")
vegan_recipe = vegan_recipe.replace("milk", "oat milk")
vegan_recipe = vegan_recipe.replace("butter", "olive oil")
print(vegan_recipe)

# Example: Bleeping out a target word in a sentence

def bleep(sentence, word):
    return sentence.replace(word, "")
    

sentence = "UGA is not a bad school!"
print(bleep(sentence, "not"))

# === Strings: escape sequences
print("\nEscape Sequences:")
print("---------------------------")
# newline character -> \n
print("Hello\nFriends!")
# tab character -> \t
print("Hello\tFriends!")
# backslash -> \\

# " -> \"
# ' -> \'

# Both \n and \t are considered whitespace characters. A space is also a whitespace character. 

# even though we type two characters when making \n, python interprets as a single character the new line character
print("The dog is white.\nThe cat is gray") # this prints a new line between the two sentences

# we create tabs using \t
print("The dog is white.\tThe cat is gray") # prints a tab between the 2 sentences.

# We can use \ as escape characters.
# by putting a \ in front of the 's python treats the ' as an actual character.
print('Ronnie\'s baby is almost 7 months')

# we can put a \ in front of a \ in order to print a single \
print("This is how you would use backslash \\")

# what if I want to actually print the string \n instead of a new line?
# well, I stick a \ in front of it
print("This is a way that I can print \\n instead of a new line character.")


# === Strings: .strip()
print("\n.strip() method:")
print("---------------------------")

# the .strip() method is a string method that removes leading and trailing whitespace characters (such as \n, \t or spaces)
aMessySent = "  \t \t\t  Have a great Saturday \n\n\n"
print(aMessySent.strip())
print(aMessySent)




# === Strings into lists: .split()
print("\n.split() method")
print("---------------------------")
# The basics
#.split() method takes a string and splits it into a list and returns that list
# the default behavior of .split() is to separate on spaces
# but you could pass a string into .split() and separate on that instead
phrase = "This is delicious!"
phrase_list = phrase.split() # split defaults to splitting on spaces
print(phrase_list) #['This', 'is', 'delicious!']


# we can also split on a character or characters of our choosing
phrase = "This is delicious!"
new_phrase_list =phrase.split("T")
print(new_phrase_list) # ['', 'his is delicious!']

new_phrase_list2 = phrase.split("!")
print(new_phrase_list2) # ['This is delicious', '']




# you can also split on a multistring substring
new_phrase_list = phrase.split("is")
print(new_phrase_list)


# comma separated strings are very common in the real world since they are stored in csv files
my4thOfJuly = "Chips,salsa,veggies,salsa" # comma separated values
my_4th_of_July_list = my4thOfJuly.split(",")
print(my_4th_of_July_list)