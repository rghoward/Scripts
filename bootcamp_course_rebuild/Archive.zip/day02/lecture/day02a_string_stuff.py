# === String indexing
# string indexing allows access to individual characters in a string
# indexing starts at 0 (not 1)
# i.e to get the first character, you are getting the 0th character
print("\nString Indexing:")
print("-----------------------------------")

my_str = "Hello my name is Ronnie."

# to get first character:
print(my_str[0]) # get the 1st character
print(my_str[3]) # get the 4th character

# length function: 
# gives the length of the string
print(len(my_str)) # 24 because there are 24 characters in the string above

# to get last character of string:
# this won't work because len(my_str) is 24 but since we start indexing at 0,
# the last character is at index 23
# my_str[len(my_str)] # IndexError: string index out of range

print(my_str[len(my_str)-1]) # works since len(my_str) is 24 and 24-1 = 23 the last index

# another way to get last character:
print(my_str[-1]) # -1 gives last character
print(my_str[-2]) # # gives second to last character

# === String iteration
print("\n String iteration:")
print("-----------------------------------")

# Example: looping through the indices vs looping through the characters

phrase = "Hope you have a great holiday!"
for c in phrase:
    print(c)

# recall that the stop value of range is exclusive
# thus if we want to print out each character, 
# we can use range(len(phrase)) since it will start at 0 inclusive and go to last index

phrase = "Hello!"
for i in range(len(phrase)): # for i in range(6) > for i in [0,1,2,3,4,5]
    print(phrase[i])

for i in range(len(phrase)):
    print(str(i)+" " + phrase[i])


# === String immutability
print("\n String Immutability")
print("-----------------------------------")

# immutability means that the object cannot be changed after creation
# strings are immutable

# Example: Making the first letter of a sentence uppercase

sentence = "this class rocks!!!"
# sentence[0] = "T" # does not work! because strings are immutable

# the following does work but not because we changed the original string
# but because we stored a different string into the same variable.
sentence = "This class rocks!!!" 

# === String slicing
print("\nString slicing:")
# Basics (start:end, start:end:step)

test = 'Hope you enjoy the holiday!'

print(test[0:4])
print(test[0:7:2]) #[start:end (exclusive):step] > 0, 2, 4, 6
print(test[:10]) # starts at beginning goes up to 10 (exclusive)
print(test[9:]) # starts on index 9 and goes until the end
print(test[::2]) # begining to end in steps of 2
print(test[::-1]) # reverse the string
print(test[:]) # copy of string

print(len(test))
#print(test[100]) # index out of range error!
print(test[2:100000])
print(test[8000:]) # slicing out of range is okay, here it gives
# us an empty string
print(test[0:7:-1]) # empty string
print(test[7:0:-1]) # doesn't include first char (stop is exclusive)
print(test[7::-1]) # gives first char if no end is specified

# Example: Getting pairs of characters out of a string
# print(letterPairs("spongebobs")) # -> sp-on-ge-bo-bs


def letterPairs(aStr):
    newStr = ""
    for i in range(0,len(aStr),2):
        pair = aStr[i:i+2]
        newStr += pair + "-"
    return newStr[0:len(newStr)-1]

#print(letterPairs("spongebobs"))



# === String methods: .isupper(), .islower(), .isdigit(), .isalpha()
print("\nString methods:")
print("-----------------------------------")

# What is a method?
# a method is a function associated with some object
# methods can be thought of as a behavior of some object
# for example: len(my_str) is a function
# my_str.lower() a string has the ability to make itself lowercase


# aStr.methodName()

#.isupper() returns True if all letters are uppercase, False if not
aStr = "GOOD MORNING!!"
print(aStr.isupper()) # True since all uppercase

bStr = "Good night"
print(bStr.isupper()) # False

cStr = "!!"
print(cStr.isupper()) #False since there are no capital letters

#.islower() returns True if all letters are lowercase, False if not

dStr = "i am excited for lunch"
print(dStr.islower())

#.isdigit() returns True if all characters are digits, False if not
eStr = "4210 "
print(eStr.isdigit())# false because there  is a space

print("4210".isdigit()) # True

#.isalpha() returns True if all characters are letters, False if not
fStr = "acGbm"
print(fStr.isalpha())


# Example: checking whether a password meets the following requirements:
# it has at least one upper case, one lower case and one digit


def checkPassw(password):
    hasLower = False
    hasUpper = False
    hasDigit = False
    hasCorrectLength = len(password) >= 8
    for char in password:
        if char.isupper():
            hasUpper = True
        if char.islower():
            hasLower = True
        if char.isdigit():
            hasDigit = True
    return hasLower and hasUpper and hasDigit and hasCorrectLength


print(checkPassw("psd12"))
print(checkPassw("psdD"))
print(checkPassw("psdD321i"))


# === String methods: .upper(), .lower()

#.upper() returns upper case version of some str
phrase = "I can't wait for 4th of July!"
phraseUpper = phrase.upper()
print(phrase)
print(phraseUpper)

#.lower() returns lower case version of some str


# Example: Counting how many birthdays in a given month

def howManyBdays(bdays, month):
    count = 0
    for i in range(0, len(bdays), 4):
        # we do steps of 4 since the beginning of each month is on a multiple of 4 
        currMonth = bdays[i:i+3] # gives us the 3 letter name of month
        if currMonth.lower() == month.lower(): # we turn both to lower to compare directly
            count += 1
    return count
bdays = "Jan jun APR Jun May MAY may Feb mar"
month = "Jun"
print(f"There are {howManyBdays(bdays,month)} bdays in {month}")


# === String methods: .replace()


#.replace(substr, newsubstr) replaces all occurences of substr
# in a str with newsubstr


# Example: Making a recipe vegan

recipe = "2 eggs, 1 cup of flour, 1 cup milk, butter"
veganRecipe = recipe.replace("eggs", "aquafaba")
veganRecipe = veganRecipe.replace("milk", "oat milk")
print(recipe)
print(veganRecipe)

# Example: Bleeping out a target word in a sentence

def bleep(sentence, word):
    sentence = sentence.lower()
    word = word.lower()    
    return sentence.replace(word, "*"*len(word))

sentence = "UGA is not a bad school!"
print(bleep(sentence, "not"))

# === Strings: escape sequences
print("\nEscape Sequences:")
print("---------------------------")
# newline character -> \n
print("Hello\nFriends!")
# tab character -> \t
print("Hello\tFriends!")
# backslash -> \\

# " -> \"
# ' -> \'

# Both \n and \t are considered whitespace characters. A space is also a whitespace character. 

# even though we type two characters when making \n, python interprets as a single character the new line character
print("The dog is white.\nThe cat is gray") # this prints a new line between the two sentences

# we create tabs using \t
print("The dog is white.\tThe cat is gray") # prints a tab between the 2 sentences.

# We can use \ as escape characters.
# by putting a \ in front of the 's python treats the ' as an actual character.
print('Ronnie\'s baby is almost 7 months')

# we can put a \ in front of a \ in order to print a single \
print("This is how you would use backslash \\")

# what if I want to actually print the string \n instead of a new line?
# well, I stick a \ in front of it
print("This is a way that I can print \\n instead of a new line character.")


# === Strings: .strip()
print("\n.strip() method:")
print("---------------------------")

# the .strip() method is a string method that removes leading and trailing whitespace characters (such as \n, \t or spaces)
aMessySent = "  \t \t\t  Have a great Saturday \n\n\n"
print(aMessySent)
print(aMessySent.strip())

# notice that if I reprint aMessySent, it is still the ugly whitespace string
# this is because .strip() returns a new string.  It does not change the current string because it is immutable.
print(aMessySent)

# you could store the cleaned string in a new or the same var.
aMessySent = aMessySent.strip() # this strips the string and stores the returned string in the same variable name
print(aMessySent)

# === Strings into lists: .split()
print("\n.split() method")
print("---------------------------")
# The basics
#.split() method takes a string and splits it into a list and returns that list
# the default behavior of .split() is to separate on spaces
# but you could pass a string into .split() and separate on that instead
phrase = "This is delicious!"
phrase_list = phrase.split()
print(phrase_list) #['This', 'is', 'delicious!'] <- notice that the spaces are gone

# we can also split on a character or characters of our choosing
phrase = "This is delicious!"
new_phrase_list = phrase.split("i")
print(new_phrase_list) # ['Th', 's ', 's del', 'c', 'ous!'] <- i's are gone spaces remain because we split on i's

# you can also split on a multistring substring
new_phrase_list = phrase.split("is")
print(new_phrase_list) # splits on is to give ['Th', ' ', ' delicious!']

# Example: Use the split function to form a list of
# substrings of a grocery list, provided as a str
# with items separated by commas.

# comma separated strings are very common in the real world since they are stored in csv files
my4thOfJuly = "Chips,salsa,veggies,salsa" # comma separated values
my4thOfJulyList = my4thOfJuly.split(",")
print(my4thOfJulyList)