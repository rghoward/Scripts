
def read_pokemon_list(filename):
    with open(filename, 'r') as file:
        lines = [line.strip() for line in file]
    return lines

def write_pokemon_list(pokemon_list, filename):
    with open(filename, 'w') as file:
        for pokemon in pokemon_list:
            file.write(pokemon + '\n')

def append_pokemon_list(pokemon_list, filename):
    with open(filename, 'a') as file:
        for pokemon in pokemon_list:
            file.write(pokemon + '\n')

def remove_punctuation(input_file, output_file):
    import string
    with open(input_file, 'r') as infile, open(output_file, 'w') as outfile:
        text = infile.read()
        cleaned_text = text.translate(str.maketrans('', '', string.punctuation))
        outfile.write(cleaned_text)

def read_pokemon_csv(filename):
    import csv
    data = []
    with open(filename, 'r') as csvfile:
        reader = csv.reader(csvfile)
        for row in reader:
            data.append(row)
    return data

def write_pokemon_csv(pokemon_data, filename):
    import csv
    fieldnames = pokemon_data[0].keys()
    with open(filename, 'w', newline='') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(pokemon_data)

def load_pokemon_json(filename):
    import json
    with open(filename, 'r') as file:
        return json.load(file)

def save_pokemon_json(pokemon_data, filename):
    import json
    with open(filename, 'w') as file:
        json.dump(pokemon_data, file, indent=4)

def parse_pokemon_xml(filename):
    import xml.etree.ElementTree as ET
    tree = ET.parse(filename)
    root = tree.getroot()
    data = []
    for child in root:
        entry = {child.tag: child.attrib}
        for grandchild in child:
            entry[grandchild.tag] = grandchild.text
        data.append(entry)
    return data

def get_first_pokemon_data(filename):
    import xml.etree.ElementTree as ET
    tree = ET.parse(filename)
    root = tree.getroot()
    return root[0][0].text
