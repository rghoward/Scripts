import requests  # import requests module so we can make http requests

def non_json_request_example():
    # let's look at a non-json reponse
    url = "https://cc.gatech.edu"
    r = requests.get(url)
    print(r.status_code)
    print(r.text[:10000])
    # print(r.json()) # this doesn't work because it isn't a json response (it is html response)
    

def requests_example():
    url = "https://anapioficeandfire.com/api"
    response = requests.get(url)
    print(response) # prints a response object along with the status code
    print(response.status_code) # you should typically check to see if this 200 before doing anything else
    print(response.text)# prints the text
    # the text looks a json object so let's use response.json()
    data = response.json() # converts the json formatted string to a dict
    print(type(data))
    print(data.keys())


# List the titles of all the Game of Thrones books in alphabetical order.
def alphabetize_books():
    url = "https://anapioficeandfire.com/api/books"
    r = requests.get(url)
    # we know from documentation that the response is in json format
    # we also know that the response is a list of dicts
    data = r.json()

    book_list = [] # make an empty list to store book names
    for book in data: # book is a dictionary containing information about a book from GoT
        book_list.append(book["name"])
    book_list.sort(key=lambda s: (s.split()[1], s.split()[2]))
    print(book_list)

# 1. How many houses exist in the universe of fire and ice?
def houses_in_fire_and_ice():
    url = "https://anapioficeandfire.com/api/houses"
    r = requests.get(url)
    data = r.json() # data is a list as seen from the documentation
    print(f"There are {len(data)} houses in GoT")

# 2. Which of the houses have the most sworn members?
def most_sworn_members():
    url = "https://anapioficeandfire.com/api/houses"
    r = requests.get(url)
    data = r.json()
    house_name = ""
    most_members = 0

    for house in data:
        num_members = len(house["swornMembers"])
        if num_members > most_members:
            most_members = num_members
            house_name = house["name"]
    print(f"{house_name} is the largest house with {most_members} members.")


# 3. What is the title of the book that is the most pages long?
def longest_book():
    url = "https://anapioficeandfire.com/api/books"
    r = requests.get(url)
    data = r.json()

    most_pages = 0
    biggest_book = ""
    for book in data:
        pages = book["numberOfPages"]
        if pages > most_pages:
            most_pages = pages
            biggest_book = book["name"]
    print(f"{biggest_book} is the longest at {most_pages} pages.")


if __name__ == "__main__":
    # requests_example()
    # alphabetize_books()
    # houses_in_fire_and_ice()
    # most_sworn_members()
    # longest_book()
    # non_json_request_example()